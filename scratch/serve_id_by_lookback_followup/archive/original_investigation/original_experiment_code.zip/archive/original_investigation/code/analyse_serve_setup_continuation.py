"""Measure serve-setup evidence as a later-contact correction signal."""

from __future__ import annotations

import argparse
import gzip
import json
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np

from annotator.calibration.fixtures import FIXTURES
from annotator.fps_constants import scale_for_fps
from annotator.rally.serve import (
    PLAYER_PRESENT_MIN_FRAC,
    ServeSetupInputs,
    _sticky_serve_setup_before,
    build_serve_setup_inputs,
)
from annotator.types import Slot
from scratch.serve_id_by_lookback_followup.analyse_additive_correction import (
    PRIMARY_TOLERANCE_BASE30,
    CorrectionInput,
    RallyKey,
    TruthRow,
    VisibleStartCategory,
    _candidate_start_correct,
    _read_csv_gz,
    build_inputs,
    load_truth,
)
from scratch.serve_start_trajectory_exploration.experiment_data import load_video_data
from scratch.serve_start_trajectory_exploration.trajectory_features import (
    align_anchor_to_gt,
)

RUN_DIR = Path(__file__).resolve().parent
CONTACT_EVIDENCE_PATH = RUN_DIR / "h3_r8_contact_evidence.csv.gz"
SUMMARY_PATH = RUN_DIR / "serve_setup_continuation_summary.json.gz"

# This is the existing accepted-contact wrist threshold. ServeStartConfig has no
# default threshold, so the experiment does not claim that 1.4 is a shipped
# serve-start setting.
WRIST_THRESHOLD_BH = 1.4
EXPECTED_RALLIES = 239


@dataclass(frozen=True, slots=True)
class ContactEvidence:
    """GT-free accepted-contact fields used by the setup checks."""

    rank: int
    frame: int
    player: str
    pre_verdict: str


@dataclass(frozen=True, slots=True)
class SetupCandidate:
    """One later accepted contact selected without GT."""

    frame: int
    player: str
    rank: int
    gap_frames: int


def load_contact_evidence() -> dict[RallyKey, tuple[ContactEvidence, ...]]:
    """Project GT-free fields from the saved H3 per-contact table."""
    fields, rows = _read_csv_gz(CONTACT_EVIDENCE_PATH)
    policy_fields = ("accepted_rank", "contact_frame", "player", "pre_verdict")
    if "gt_stroke_frames" in fields:
        gt_boundary = fields.index("gt_stroke_frames")
        if any(fields.index(field) >= gt_boundary for field in policy_fields):
            raise ValueError("A serve-setup policy field crosses the GT boundary")

    grouped: dict[RallyKey, list[ContactEvidence]] = {}
    for row in rows:
        key = (row["fixture"], int(row["video_id"]), row["set_id"], int(row["rally"]))
        grouped.setdefault(key, []).append(
            ContactEvidence(
                rank=int(row["accepted_rank"]),
                frame=int(row["contact_frame"]),
                player=row["player"],
                pre_verdict=row["pre_verdict"],
            )
        )
    contacts_by_key = {
        key: tuple(sorted(contacts, key=lambda contact: contact.rank))
        for key, contacts in grouped.items()
    }
    if len(contacts_by_key) != EXPECTED_RALLIES:
        raise ValueError("Expected contact evidence for 239 rallies")
    return contacts_by_key


def _slot_player(slot: Slot) -> str:
    """Return the saved player spelling for one sticky slot."""
    return "Top" if slot is Slot.TOP else "Bot"


def _setup_passes(setup: ServeSetupInputs, frame: int, lookback_frames: int) -> bool:
    """Apply the existing serve-setup primitive with the fixed wrist threshold."""
    return _sticky_serve_setup_before(
        setup,
        frame,
        WRIST_THRESHOLD_BH,
        lookback_frames,
        None,
        None,
    )


def _continued_setup_slot(
    setup: ServeSetupInputs,
    early_frame: int,
    candidate_frame: int,
) -> Slot | None:
    """Find one player who retains close wrist evidence after the early impulse."""
    suffix = slice(early_frame + 1, candidate_frame)
    if suffix.start >= suffix.stop or not np.all(setup.analysed[suffix]):
        return None
    if float(np.median(setup.count[suffix])) < 1:
        return None

    passing_slots: list[Slot] = []
    for slot in Slot:
        distances = setup.wrist_dist[suffix, slot]
        heights = setup.top_height[suffix] if slot is Slot.TOP else setup.bot_height[suffix]
        valid = np.isfinite(distances) & np.isfinite(heights)
        if np.mean(valid) < PLAYER_PRESENT_MIN_FRAC or np.count_nonzero(valid) < 2:
            continue
        if np.all(distances[valid] / heights[valid] <= WRIST_THRESHOLD_BH):
            passing_slots.append(slot)
    return passing_slots[0] if len(passing_slots) == 1 else None


def _fixture_setups() -> dict[str, ServeSetupInputs]:
    """Rebuild only the production sticky setup fields for each fixture."""
    setups: dict[str, ServeSetupInputs] = {}
    for fixture in FIXTURES:
        data = load_video_data(fixture)
        setups[fixture.name] = build_serve_setup_inputs(data.sticky, fixture.resolution)
    return setups


def freeze_candidates(
    inputs: Sequence[CorrectionInput],
) -> dict[str, dict[RallyKey, tuple[SetupCandidate, ...]]]:
    """Freeze both serve-setup variants before GT scoring."""
    contacts_by_key = load_contact_evidence()
    setups = _fixture_setups()
    broad: dict[RallyKey, tuple[SetupCandidate, ...]] = {}
    continued: dict[RallyKey, tuple[SetupCandidate, ...]] = {}

    for row in inputs:
        contacts = contacts_by_key[row.key]
        setup = setups[row.fixture]
        lookback_frames = scale_for_fps(row.fps).serve_start_lookback_frames

        broad_candidates: list[SetupCandidate] = []
        if not _setup_passes(setup, row.baseline_frame, lookback_frames):
            for contact in contacts[1:]:
                if _setup_passes(setup, contact.frame, lookback_frames):
                    broad_candidates.append(
                        SetupCandidate(
                            frame=contact.frame,
                            player=contact.player,
                            rank=contact.rank,
                            gap_frames=contact.frame - row.baseline_frame,
                        )
                    )
                    break
        broad[row.key] = tuple(broad_candidates)

        continued_candidates: list[SetupCandidate] = []
        for contact in contacts[1:]:
            gap_frames = contact.frame - row.baseline_frame
            if gap_frames > lookback_frames:
                break
            if contact.pre_verdict != "not_incoming" or contact.player != row.baseline_player:
                continue
            if not _setup_passes(setup, contact.frame, lookback_frames):
                continue
            slot = _continued_setup_slot(setup, row.baseline_frame, contact.frame)
            if slot is None or _slot_player(slot) != contact.player:
                continue
            continued_candidates.append(
                SetupCandidate(
                    frame=contact.frame,
                    player=contact.player,
                    rank=contact.rank,
                    gap_frames=gap_frames,
                )
            )
        continued[row.key] = tuple(continued_candidates)

    return {
        "broad_gate_differential": broad,
        "continued_same_player_setup": continued,
    }


def _score_variant(
    inputs: Sequence[CorrectionInput],
    candidates_by_key: Mapping[RallyKey, tuple[SetupCandidate, ...]],
    truth_by_key: Mapping[RallyKey, TruthRow],
) -> dict[str, object]:
    """Score one frozen candidate map after GT is joined."""
    start_outcomes: Counter[str] = Counter()
    server_outcomes: Counter[str] = Counter()
    old_unmatched_outcomes: Counter[str] = Counter()
    interventions = 0
    conflicts = 0
    server_changes = 0

    for row in inputs:
        truth = truth_by_key[row.key]
        candidates = candidates_by_key[row.key]
        baseline_start_correct = _candidate_start_correct(
            row,
            truth,
            frame=row.baseline_frame,
            category=row.baseline_category,
        )
        old_unmatched = (
            align_anchor_to_gt(
                row.baseline_frame,
                truth.stroke_frames,
                row.fps,
                PRIMARY_TOLERANCE_BASE30,
            ).label
            == "unmatched"
        )

        if not candidates:
            outcome = (
                "baseline_correct_no_change"
                if baseline_start_correct
                else "baseline_wrong_no_change"
            )
        elif len(candidates) > 1:
            conflicts += 1
            outcome = "conflict_unresolved"
        else:
            interventions += 1
            candidate = candidates[0]
            corrected_start_correct = _candidate_start_correct(
                row,
                truth,
                frame=candidate.frame,
                category=VisibleStartCategory.VISIBLE_SERVE,
            )
            if not baseline_start_correct and corrected_start_correct:
                outcome = "fixed_by_correction"
            elif baseline_start_correct and not corrected_start_correct:
                outcome = "damaged_by_correction"
            else:
                outcome = "changed_without_score_change"

            if candidate.player != row.baseline_server:
                server_changes += 1
                baseline_server_correct = row.baseline_server == truth.server
                corrected_server_correct = candidate.player == truth.server
                if not baseline_server_correct and corrected_server_correct:
                    server_outcomes["fixed_by_correction"] += 1
                elif baseline_server_correct and not corrected_server_correct:
                    server_outcomes["damaged_by_correction"] += 1
                else:
                    server_outcomes["changed_without_score_change"] += 1

        start_outcomes[outcome] += 1
        if old_unmatched:
            old_unmatched_outcomes[outcome] += 1

    fixes = start_outcomes["fixed_by_correction"]
    damage = start_outcomes["damaged_by_correction"]
    return {
        "interventions": interventions,
        "conflicts": conflicts,
        "fixes": fixes,
        "damage": damage,
        "net_fixes": fixes - damage,
        "intervention_precision": fixes / interventions if interventions else None,
        "start_outcomes": dict(sorted(start_outcomes.items())),
        "old_97_unmatched_slice": dict(sorted(old_unmatched_outcomes.items())),
        "server_changes": server_changes,
        "server_outcomes": dict(sorted(server_outcomes.items())),
    }


def build_summary() -> dict[str, object]:
    """Freeze both variants, then join GT and score them."""
    inputs = build_inputs()
    candidates_by_variant = freeze_candidates(inputs)
    truth_by_key = load_truth()
    return {
        "schema": "serve_setup_continuation_summary/1",
        "population": len(inputs),
        "fixed_parameters": {
            "wrist_threshold_bh": WRIST_THRESHOLD_BH,
            "wrist_threshold_source": "accepted-contact gate",
            "lookback_source": "serve_start_lookback_frames",
            "stillness_gate": "off",
        },
        "variants": {
            name: _score_variant(inputs, candidates, truth_by_key)
            for name, candidates in candidates_by_variant.items()
        },
        "frozen_candidates": {
            name: {
                "|".join(map(str, key)): [asdict(candidate) for candidate in candidates]
                for key, candidates in candidate_map.items()
                if candidates
            }
            for name, candidate_map in candidates_by_variant.items()
        },
    }


def _write_gzip_text(path: Path, text: str) -> None:
    """Write deterministic gzip text."""
    with path.open("wb") as raw_handle, gzip.GzipFile(
        filename="",
        mode="wb",
        fileobj=raw_handle,
        compresslevel=9,
        mtime=0,
    ) as gzip_handle:
        gzip_handle.write(text.encode("utf-8"))


def main() -> None:
    """Write or check the deterministic serve-setup summary."""
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write", action="store_true")
    mode.add_argument("--check", action="store_true")
    args = parser.parse_args()

    text = json.dumps(build_summary(), indent=2, sort_keys=True) + "\n"
    if args.write:
        _write_gzip_text(SUMMARY_PATH, text)
    else:
        with gzip.open(SUMMARY_PATH, "rt") as handle:
            if handle.read() != text:
                raise AssertionError(f"Saved serve-setup summary differs: {SUMMARY_PATH}")
    print(text, end="")


if __name__ == "__main__":
    main()
