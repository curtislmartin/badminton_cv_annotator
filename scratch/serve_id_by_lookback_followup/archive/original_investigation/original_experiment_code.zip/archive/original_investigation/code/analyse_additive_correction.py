"""Apply the supported H3/R8 evidence as a correction to the PR #82 result."""

from __future__ import annotations

import argparse
import csv
import gzip
import io
import json
from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from enum import StrEnum
from pathlib import Path
from typing import TypeAlias

from scratch.serve_start_trajectory_exploration.trajectory_features import (
    align_anchor_to_gt,
)

RUN_DIR = Path(__file__).resolve().parent
H3_CONTACT_EVIDENCE_PATH = RUN_DIR / "h3_r8_contact_evidence.csv.gz"
H3_SEARCH_RESULTS_PATH = RUN_DIR / "h3_r8_search_results.csv.gz"
PR82_RALLIES_PATH = RUN_DIR.parent / "serve_start_trajectory_exploration" / "outputs" / "rallies.csv.gz"
RESULTS_PATH = RUN_DIR / "additive_correction_results.csv.gz"
SUMMARY_PATH = RUN_DIR / "additive_correction_summary.json.gz"

PRIMARY_TOLERANCE_BASE30 = 10
EXPECTED_RALLIES = 239

RallyKey: TypeAlias = tuple[str, int, str, int]


class VisibleStartCategory(StrEnum):
    """The GT contact ordinal expected at the visible start frame."""

    VISIBLE_SERVE = "visible_serve"
    FIRST_VISIBLE_POST_SERVE_CONTACT = "first_visible_post_serve_contact"


class CorrectionAction(StrEnum):
    """What the optional correction layer does to the existing answer."""

    CORRECT = "correct"
    NO_OP = "no_op"
    CONFLICT = "conflict"


class CorrectionReason(StrEnum):
    """Why the correction layer changed or retained the existing answer."""

    HIGH_SHOT_VISIBLE_SERVE = "high_shot_visible_serve"
    STRONG_EVIDENCE_AGREES = "strong_evidence_agrees_with_baseline"
    ORDINARY_PREDECESSOR_WEAK = "ordinary_predecessor_is_weak"
    NO_SUPPORTED_CORRECTION = "no_supported_correction"


@dataclass(frozen=True, slots=True)
class CorrectionInput:
    """GT-free baseline and saved H3/R8 evidence for one rally."""

    fixture: str
    video_id: int
    set_id: str
    rally: int
    fps: float
    accepted_contact_frames: tuple[int, ...]
    baseline_frame: int
    baseline_category: VisibleStartCategory
    baseline_player: str
    baseline_server: str
    h3_first_pre_verdict: str
    incoming_category: str
    incoming_anchor_frame: int | None
    incoming_anchor_rank: int | None
    incoming_anchor_player: str | None
    incoming_predecessor_frame: int | None
    incoming_predecessor_rank: int | None
    incoming_predecessor_player: str | None
    incoming_predecessor_verdict: str | None
    incoming_admission: str
    incoming_stop_reason: str
    incoming_high_shot_start: int | None
    incoming_high_shot_end: int | None

    @property
    def key(self) -> RallyKey:
        """Return the stable rally identity."""
        return self.fixture, self.video_id, self.set_id, self.rally


@dataclass(frozen=True, slots=True)
class FrozenCorrection:
    """One decision made before GT is loaded."""

    fixture: str
    video_id: int
    set_id: str
    rally: int
    fps: float
    baseline_frame: int
    baseline_category: str
    baseline_player: str
    baseline_server: str
    correction_action: str
    correction_reason: str
    corrected_frame: int
    corrected_category: str
    corrected_player: str
    corrected_server: str
    h3_first_pre_verdict: str
    incoming_admission: str
    incoming_stop_reason: str
    incoming_predecessor_frame: int | None
    incoming_predecessor_rank: int | None
    incoming_predecessor_verdict: str | None
    incoming_high_shot_start: int | None
    incoming_high_shot_end: int | None

    @property
    def key(self) -> RallyKey:
        """Return the stable rally identity."""
        return self.fixture, self.video_id, self.set_id, self.rally


@dataclass(frozen=True, slots=True)
class TruthRow:
    """GT fields loaded only after correction decisions are frozen."""

    stroke_frames: tuple[int, ...]
    server: str


def _optional_int(value: str) -> int | None:
    """Parse an optional integer CSV field."""
    return int(value) if value else None


def _parse_bool(value: str) -> bool:
    """Parse the checked CSV boolean spelling."""
    if value == "True":
        return True
    if value == "False":
        return False
    raise ValueError(f"Expected checked boolean, got {value!r}")


def _read_csv_gz(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    """Read one compressed CSV with its declared field order."""
    with gzip.open(path, "rt", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"Missing CSV header: {path}")
        return list(reader.fieldnames), list(reader)


def _key(row: Mapping[str, str]) -> RallyKey:
    """Read the shared rally key from a CSV row."""
    return row["fixture"], int(row["video_id"]), row["set_id"], int(row["rally"])


def build_inputs() -> list[CorrectionInput]:
    """Project only GT-free fields from the two completed investigations."""
    h3_fields, h3_rows = _read_csv_gz(H3_SEARCH_RESULTS_PATH)
    gt_boundary = h3_fields.index("gt_stroke_frames")
    policy_fields = (
        "accepted_contact_frames",
        "incoming_category",
        "incoming_predecessor_frame",
        "incoming_predecessor_rank",
        "incoming_predecessor_player",
        "incoming_predecessor_verdict",
        "incoming_admission",
        "incoming_stop_reason",
        "incoming_high_shot_start",
        "incoming_high_shot_end",
    )
    if any(h3_fields.index(field) >= gt_boundary for field in policy_fields):
        raise ValueError("A correction policy field crosses the H3/R8 GT boundary")

    _, contact_rows = _read_csv_gz(H3_CONTACT_EVIDENCE_PATH)
    h3_first_by_key = {_key(row): row for row in contact_rows if int(row["accepted_rank"]) == 1}

    _, pr82_rows = _read_csv_gz(PR82_RALLIES_PATH)
    pr82_primary = [row for row in pr82_rows if _parse_bool(row["primary_one_to_one"])]
    pr82_by_key = {_key(row): row for row in pr82_primary}
    h3_by_key = {_key(row): row for row in h3_rows}
    if not len(h3_by_key) == len(h3_first_by_key) == len(pr82_by_key) == EXPECTED_RALLIES:
        raise ValueError("Expected 239 unique one-to-one rally rows in every input")
    if not h3_by_key.keys() == h3_first_by_key.keys() == pr82_by_key.keys():
        raise ValueError("The H3/R8 and PR #82 rally keys differ")

    inputs: list[CorrectionInput] = []
    for key, h3_row in h3_by_key.items():
        pr82_row = pr82_by_key[key]
        first_evidence = h3_first_by_key[key]
        accepted_frames = tuple(int(frame) for frame in json.loads(h3_row["accepted_contact_frames"]))
        baseline_frame = int(float(pr82_row["anchor_frame"]))
        if not accepted_frames or baseline_frame != accepted_frames[0]:
            raise ValueError(f"PR #82 anchor does not match the first H3/R8 contact: {key}")

        baseline_incoming = _parse_bool(pr82_row["recurrence_clean_robust_trend_incoming"])
        baseline_category = (
            VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT
            if baseline_incoming
            else VisibleStartCategory.VISIBLE_SERVE
        )
        fixture, video_id, set_id, rally = key
        inputs.append(
            CorrectionInput(
                fixture=fixture,
                video_id=video_id,
                set_id=set_id,
                rally=rally,
                fps=float(h3_row["fps"]),
                accepted_contact_frames=accepted_frames,
                baseline_frame=baseline_frame,
                baseline_category=baseline_category,
                baseline_player=pr82_row["anchor_player"],
                baseline_server=pr82_row["motion_rule_server"],
                h3_first_pre_verdict=first_evidence["pre_verdict"],
                incoming_category=h3_row["incoming_category"],
                incoming_anchor_frame=_optional_int(h3_row["incoming_anchor_frame"]),
                incoming_anchor_rank=_optional_int(h3_row["incoming_anchor_rank"]),
                incoming_anchor_player=h3_row["incoming_anchor_player"] or None,
                incoming_predecessor_frame=_optional_int(h3_row["incoming_predecessor_frame"]),
                incoming_predecessor_rank=_optional_int(h3_row["incoming_predecessor_rank"]),
                incoming_predecessor_player=h3_row["incoming_predecessor_player"] or None,
                incoming_predecessor_verdict=h3_row["incoming_predecessor_verdict"] or None,
                incoming_admission=h3_row["incoming_admission"],
                incoming_stop_reason=h3_row["incoming_stop_reason"],
                incoming_high_shot_start=_optional_int(h3_row["incoming_high_shot_start"]),
                incoming_high_shot_end=_optional_int(h3_row["incoming_high_shot_end"]),
            )
        )
    return inputs


def decide_correction(row: CorrectionInput) -> FrozenCorrection:
    """Apply the one supported positive evidence state to the existing answer."""
    strong_high_shot_serve = (
        row.incoming_admission == "high_shot_oob"
        and row.incoming_stop_reason == "predecessor_admitted_by_high_shot_oob"
        and row.incoming_category == VisibleStartCategory.VISIBLE_SERVE
        and row.incoming_predecessor_verdict == "not_incoming"
    )

    corrected_frame = row.baseline_frame
    corrected_category = row.baseline_category
    corrected_player = row.baseline_player
    corrected_server = row.baseline_server
    action = CorrectionAction.NO_OP

    if strong_high_shot_serve:
        target_frame = row.incoming_predecessor_frame
        target_player = row.incoming_predecessor_player
        if target_frame is None or target_player is None:
            raise ValueError(f"High-shot evidence lacks a target: {row.key}")
        if target_frame not in row.accepted_contact_frames:
            raise ValueError(f"High-shot target is not an accepted contact: {row.key}")

        target_category = VisibleStartCategory.VISIBLE_SERVE
        target_differs = target_frame != row.baseline_frame or target_category != row.baseline_category
        if target_differs:
            action = CorrectionAction.CORRECT
            reason = CorrectionReason.HIGH_SHOT_VISIBLE_SERVE
            corrected_frame = target_frame
            corrected_category = target_category
            corrected_player = target_player
            corrected_server = target_player
        else:
            reason = CorrectionReason.STRONG_EVIDENCE_AGREES
    elif row.incoming_admission == "ordinary_window":
        reason = CorrectionReason.ORDINARY_PREDECESSOR_WEAK
    else:
        reason = CorrectionReason.NO_SUPPORTED_CORRECTION

    return FrozenCorrection(
        fixture=row.fixture,
        video_id=row.video_id,
        set_id=row.set_id,
        rally=row.rally,
        fps=row.fps,
        baseline_frame=row.baseline_frame,
        baseline_category=row.baseline_category,
        baseline_player=row.baseline_player,
        baseline_server=row.baseline_server,
        correction_action=action,
        correction_reason=reason,
        corrected_frame=corrected_frame,
        corrected_category=corrected_category,
        corrected_player=corrected_player,
        corrected_server=corrected_server,
        h3_first_pre_verdict=row.h3_first_pre_verdict,
        incoming_admission=row.incoming_admission,
        incoming_stop_reason=row.incoming_stop_reason,
        incoming_predecessor_frame=row.incoming_predecessor_frame,
        incoming_predecessor_rank=row.incoming_predecessor_rank,
        incoming_predecessor_verdict=row.incoming_predecessor_verdict,
        incoming_high_shot_start=row.incoming_high_shot_start,
        incoming_high_shot_end=row.incoming_high_shot_end,
    )


def freeze_decisions(inputs: Sequence[CorrectionInput]) -> list[FrozenCorrection]:
    """Freeze every correction before any GT fields are loaded."""
    return [decide_correction(row) for row in inputs]


def load_truth() -> dict[RallyKey, TruthRow]:
    """Load GT only after the correction decisions have been frozen."""
    _, h3_rows = _read_csv_gz(H3_SEARCH_RESULTS_PATH)
    stroke_frames_by_key = {
        _key(row): tuple(int(frame) for frame in json.loads(row["gt_stroke_frames"])) for row in h3_rows
    }
    _, pr82_rows = _read_csv_gz(PR82_RALLIES_PATH)
    primary_rows = [row for row in pr82_rows if _parse_bool(row["primary_one_to_one"])]
    truth = {
        _key(row): TruthRow(stroke_frames=stroke_frames_by_key[_key(row)], server=row["gt_server"])
        for row in primary_rows
    }
    if len(truth) != EXPECTED_RALLIES:
        raise ValueError("Expected GT for 239 one-to-one rallies")
    return truth


def _expected_gt_label(category: str) -> str:
    """Map a visible-start interpretation to its expected GT ordinal."""
    if category == VisibleStartCategory.VISIBLE_SERVE:
        return "contact_1"
    if category == VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT:
        return "contact_2"
    raise ValueError(f"Unknown visible-start category: {category}")


def _start_outcome(action: str, baseline_correct: bool, corrected_correct: bool) -> str:
    """Classify the visible-start transition."""
    if action == CorrectionAction.CONFLICT:
        return "conflict_unresolved"
    if action == CorrectionAction.NO_OP:
        return "baseline_correct_no_change" if baseline_correct else "baseline_wrong_no_change"
    if not baseline_correct and corrected_correct:
        return "fixed_by_correction"
    if baseline_correct and not corrected_correct:
        return "damaged_by_correction"
    return "changed_without_score_change"


def score_decisions(
    decisions: Sequence[FrozenCorrection], truth_by_key: Mapping[RallyKey, TruthRow]
) -> list[dict[str, object]]:
    """Append opener and server scores after the GT-free decisions are complete."""
    scored: list[dict[str, object]] = []
    for decision in decisions:
        truth = truth_by_key[decision.key]
        baseline_alignment = align_anchor_to_gt(
            decision.baseline_frame,
            truth.stroke_frames,
            decision.fps,
            PRIMARY_TOLERANCE_BASE30,
        )
        corrected_alignment = align_anchor_to_gt(
            decision.corrected_frame,
            truth.stroke_frames,
            decision.fps,
            PRIMARY_TOLERANCE_BASE30,
        )
        baseline_start_correct = baseline_alignment.label == _expected_gt_label(decision.baseline_category)
        corrected_start_correct = corrected_alignment.label == _expected_gt_label(decision.corrected_category)
        baseline_server_correct = decision.baseline_server == truth.server
        corrected_server_correct = decision.corrected_server == truth.server
        server_changed = decision.corrected_server != decision.baseline_server

        row = asdict(decision)
        row.update(
            {
                "gt_stroke_frames": json.dumps(truth.stroke_frames, separators=(",", ":")),
                "gt_server": truth.server,
                "baseline_gt_label": baseline_alignment.label,
                "corrected_gt_label": corrected_alignment.label,
                "baseline_start_correct": baseline_start_correct,
                "corrected_start_correct": corrected_start_correct,
                "start_outcome": _start_outcome(
                    decision.correction_action,
                    baseline_start_correct,
                    corrected_start_correct,
                ),
                "old_unmatched_slice": baseline_alignment.label == "unmatched",
                "baseline_server_correct": baseline_server_correct,
                "corrected_server_correct": corrected_server_correct,
                "server_changed": server_changed,
                "server_outcome": (
                    "fixed_by_correction"
                    if server_changed and not baseline_server_correct and corrected_server_correct
                    else "damaged_by_correction"
                    if server_changed and baseline_server_correct and not corrected_server_correct
                    else "changed_without_score_change"
                    if server_changed
                    else "baseline_correct_no_change"
                    if baseline_server_correct
                    else "baseline_wrong_no_change"
                ),
            }
        )
        scored.append(row)
    return scored


def _relaxed_same_anchor_audit(
    inputs: Sequence[CorrectionInput], truth_by_key: Mapping[RallyKey, TruthRow]
) -> dict[str, object]:
    """Score the rejected expansion that treats new H3 incoming calls as overrides."""
    outcomes: Counter[str] = Counter()
    server_outcomes: Counter[str] = Counter()
    triggers = 0
    for row in inputs:
        if not (
            row.baseline_category is VisibleStartCategory.VISIBLE_SERVE
            and row.h3_first_pre_verdict == "incoming"
        ):
            continue
        triggers += 1
        truth = truth_by_key[row.key]
        alignment = align_anchor_to_gt(
            row.baseline_frame,
            truth.stroke_frames,
            row.fps,
            PRIMARY_TOLERANCE_BASE30,
        )
        baseline_correct = alignment.label == "contact_1"
        candidate_correct = alignment.label == "contact_2"
        outcomes[_start_outcome(CorrectionAction.CORRECT, baseline_correct, candidate_correct)] += 1

        candidate_server = "Bot" if row.baseline_player == "Top" else "Top"
        baseline_server_correct = row.baseline_server == truth.server
        candidate_server_correct = candidate_server == truth.server
        if not baseline_server_correct and candidate_server_correct:
            server_outcomes["fixed_by_correction"] += 1
        elif baseline_server_correct and not candidate_server_correct:
            server_outcomes["damaged_by_correction"] += 1
        else:
            server_outcomes["changed_without_score_change"] += 1

    return {
        "triggers": triggers,
        "start_outcomes": dict(sorted(outcomes.items())),
        "server_outcomes": dict(sorted(server_outcomes.items())),
    }


def _candidate_start_correct(
    row: CorrectionInput,
    truth: TruthRow,
    *,
    frame: int,
    category: VisibleStartCategory,
) -> bool:
    """Score one pre-declared candidate result after its GT-free state is selected."""
    alignment = align_anchor_to_gt(frame, truth.stroke_frames, row.fps, PRIMARY_TOLERANCE_BASE30)
    return alignment.label == _expected_gt_label(category)


def _integrated_candidate_audit(
    inputs: Sequence[CorrectionInput], truth_by_key: Mapping[RallyKey, TruthRow]
) -> dict[str, object]:
    """Measure small existing-server combinations that remain too weak to override."""
    ordinary_pair: list[CorrectionInput] = []
    missing_serve_anchor: list[CorrectionInput] = []
    for row in inputs:
        if (
            row.incoming_admission == "ordinary_window"
            and row.incoming_category == VisibleStartCategory.VISIBLE_SERVE
            and row.incoming_predecessor_verdict == "not_incoming"
            and row.incoming_predecessor_frame is not None
            and row.incoming_predecessor_frame != row.baseline_frame
            and row.incoming_predecessor_player is not None
            and row.incoming_anchor_player is not None
            and row.incoming_predecessor_player != row.incoming_anchor_player
        ):
            ordinary_pair.append(row)

        if (
            row.incoming_admission == "none"
            and row.incoming_category == VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT
            and row.incoming_anchor_frame is not None
            and row.incoming_anchor_rank is not None
            and row.incoming_anchor_rank > 1
            and row.incoming_anchor_player is not None
            and row.incoming_anchor_player != row.baseline_server
        ):
            missing_serve_anchor.append(row)

    ordinary_outcomes: Counter[str] = Counter()
    ordinary_server_outcomes: Counter[str] = Counter()
    for row in ordinary_pair:
        if row.incoming_predecessor_frame is None or row.incoming_predecessor_player is None:
            raise ValueError(f"Ordinary pair lacks its selected predecessor: {row.key}")
        truth = truth_by_key[row.key]
        baseline_correct = _candidate_start_correct(
            row,
            truth,
            frame=row.baseline_frame,
            category=row.baseline_category,
        )
        candidate_correct = _candidate_start_correct(
            row,
            truth,
            frame=row.incoming_predecessor_frame,
            category=VisibleStartCategory.VISIBLE_SERVE,
        )
        ordinary_outcomes[_start_outcome(CorrectionAction.CORRECT, baseline_correct, candidate_correct)] += 1
        if row.incoming_predecessor_player != row.baseline_server:
            baseline_server_correct = row.baseline_server == truth.server
            candidate_server_correct = row.incoming_predecessor_player == truth.server
            if not baseline_server_correct and candidate_server_correct:
                ordinary_server_outcomes["fixed_by_correction"] += 1
            elif baseline_server_correct and not candidate_server_correct:
                ordinary_server_outcomes["damaged_by_correction"] += 1
            else:
                ordinary_server_outcomes["changed_without_score_change"] += 1

    ordinary_agrees_with_server = sum(
        row.incoming_predecessor_player == row.baseline_server for row in ordinary_pair
    )
    ordinary_contradicts_server = len(ordinary_pair) - ordinary_agrees_with_server

    missing_serve_outcomes: Counter[str] = Counter()
    for row in missing_serve_anchor:
        if row.incoming_anchor_frame is None:
            raise ValueError(f"Missing-serve state lacks its incoming anchor: {row.key}")
        truth = truth_by_key[row.key]
        baseline_correct = _candidate_start_correct(
            row,
            truth,
            frame=row.baseline_frame,
            category=row.baseline_category,
        )
        candidate_correct = _candidate_start_correct(
            row,
            truth,
            frame=row.incoming_anchor_frame,
            category=VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT,
        )
        missing_serve_outcomes[
            _start_outcome(CorrectionAction.CORRECT, baseline_correct, candidate_correct)
        ] += 1

    return {
        "ordinary_measured_serve_return_pair": {
            "candidates": len(ordinary_pair),
            "start_outcomes": dict(sorted(ordinary_outcomes.items())),
            "predecessor_agrees_with_existing_server": ordinary_agrees_with_server,
            "predecessor_contradicts_existing_server": ordinary_contradicts_server,
            "contradicting_server_outcomes": dict(sorted(ordinary_server_outcomes.items())),
        },
        "unshown_serve_anchor_consistent_with_existing_server": {
            "candidates": len(missing_serve_anchor),
            "start_outcomes": dict(sorted(missing_serve_outcomes.items())),
        },
    }


def build_summary(
    inputs: Sequence[CorrectionInput],
    scored_rows: Sequence[Mapping[str, object]],
    truth_by_key: Mapping[RallyKey, TruthRow],
) -> dict[str, object]:
    """Build the compact correction and no-op counts."""
    start_outcomes = Counter(str(row["start_outcome"]) for row in scored_rows)
    server_outcomes = Counter(str(row["server_outcome"]) for row in scored_rows)
    actions = Counter(str(row["correction_action"]) for row in scored_rows)
    reasons = Counter(str(row["correction_reason"]) for row in scored_rows)
    unmatched_rows = [row for row in scored_rows if bool(row["old_unmatched_slice"])]
    unmatched_outcomes = Counter(str(row["start_outcome"]) for row in unmatched_rows)
    unmatched_server_outcomes = Counter(str(row["server_outcome"]) for row in unmatched_rows)
    interventions = actions[CorrectionAction.CORRECT]
    fixes = start_outcomes["fixed_by_correction"]
    damage = start_outcomes["damaged_by_correction"]

    high_shot_rows = [row for row in inputs if row.incoming_admission == "high_shot_oob"]
    return {
        "schema": "additive_trajectory_correction_summary/1",
        "population": len(scored_rows),
        "primary_tolerance_base30": PRIMARY_TOLERANCE_BASE30,
        "policy": {
            "baseline": "PR #82 visible-start result",
            "positive_evidence": "measured high_shot_oob predecessor classified as a visible serve",
            "ordinary_predecessor": "no_op",
            "unavailable_or_ambiguous": "no_op",
            "outgoing_first": "not_used",
        },
        "actions": dict(sorted(actions.items())),
        "reasons": dict(sorted(reasons.items())),
        "start_outcomes": dict(sorted(start_outcomes.items())),
        "old_97_unmatched_slice": dict(sorted(unmatched_outcomes.items())),
        "old_97_unmatched_server": {
            "baseline_correct": sum(bool(row["baseline_server_correct"]) for row in unmatched_rows),
            "corrected_correct": sum(bool(row["corrected_server_correct"]) for row in unmatched_rows),
            "outcomes": dict(sorted(unmatched_server_outcomes.items())),
        },
        "headline": {
            "interventions": interventions,
            "fixes": fixes,
            "damage": damage,
            "net_fixes": fixes - damage,
            "intervention_precision": fixes / interventions if interventions else None,
            "baseline_start_correct": sum(bool(row["baseline_start_correct"]) for row in scored_rows),
            "corrected_start_correct": sum(bool(row["corrected_start_correct"]) for row in scored_rows),
        },
        "server_attribution": {
            "baseline_correct": sum(bool(row["baseline_server_correct"]) for row in scored_rows),
            "corrected_correct": sum(bool(row["corrected_server_correct"]) for row in scored_rows),
            "changed_answers": sum(bool(row["server_changed"]) for row in scored_rows),
            "outcomes": dict(sorted(server_outcomes.items())),
        },
        "high_shot_evidence_states": {
            "count": len(high_shot_rows),
            "target_already_baseline": sum(
                row.incoming_predecessor_frame == row.baseline_frame for row in high_shot_rows
            ),
            "target_differs_from_baseline": sum(
                row.incoming_predecessor_frame != row.baseline_frame for row in high_shot_rows
            ),
        },
        "rejected_relaxed_same_anchor_incoming": _relaxed_same_anchor_audit(inputs, truth_by_key),
        "rejected_integrated_candidates": _integrated_candidate_audit(inputs, truth_by_key),
    }


def _csv_text(rows: Sequence[Mapping[str, object]]) -> str:
    """Serialise result rows deterministically."""
    if not rows:
        raise ValueError("Cannot serialise an empty result")
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0].keys()), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue()


def _write_gzip_text(path: Path, text: str) -> None:
    """Write deterministic gzip text."""
    with path.open("wb") as raw_handle, gzip.GzipFile(
        filename="",
        mode="wb",
        fileobj=raw_handle,
        compresslevel=9,
        mtime=0,
    ) as gzip_handle:
        gzip_handle.write(text.encode("utf-8"))


def run(*, write: bool) -> dict[str, object]:
    """Build the GT-free decisions, then score and write or check them."""
    inputs = build_inputs()
    decisions = freeze_decisions(inputs)
    truth_by_key = load_truth()
    scored_rows = score_decisions(decisions, truth_by_key)
    summary = build_summary(inputs, scored_rows, truth_by_key)

    csv_text = _csv_text(scored_rows)
    summary_text = json.dumps(summary, indent=2, sort_keys=True) + "\n"
    if write:
        _write_gzip_text(RESULTS_PATH, csv_text)
        _write_gzip_text(SUMMARY_PATH, summary_text)
    else:
        with gzip.open(RESULTS_PATH, "rt", newline="") as handle:
            if handle.read() != csv_text:
                raise AssertionError(f"Saved correction rows differ: {RESULTS_PATH}")
        with gzip.open(SUMMARY_PATH, "rt") as handle:
            if handle.read() != summary_text:
                raise AssertionError(f"Saved correction summary differs: {SUMMARY_PATH}")
    return summary


def main() -> None:
    """Run explicit write or deterministic check mode."""
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write", action="store_true", help="Write the checked correction outputs")
    mode.add_argument("--check", action="store_true", help="Rebuild and compare the saved outputs")
    args = parser.parse_args()
    summary = run(write=args.write)
    print(json.dumps(summary["headline"], indent=2, sort_keys=True))
    print(json.dumps(summary["server_attribution"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
