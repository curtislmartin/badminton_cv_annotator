"""Focused tests for the rejected serve-setup continuation state."""

import numpy as np

from annotator.rally.serve import ServeSetupInputs
from annotator.types import Slot
from scratch.serve_id_by_lookback_followup.analyse_serve_setup_continuation import (
    _continued_setup_slot,
)


def _setup() -> ServeSetupInputs:
    """Return six analysed frames with only Top near the shuttle."""
    wrist_dist = np.full((6, 2), np.inf)
    wrist_dist[:, Slot.TOP] = 0.1
    return ServeSetupInputs(
        count=np.ones(6),
        wrist_dist=wrist_dist,
        analysed=np.ones(6, dtype=bool),
        top_ankles=np.zeros((6, 2)),
        bot_ankles=np.zeros((6, 2)),
        top_height=np.full(6, 0.2),
        bot_height=np.full(6, 0.2),
    )


def test_continued_setup_requires_one_close_player() -> None:
    assert _continued_setup_slot(_setup(), early_frame=1, candidate_frame=5) is Slot.TOP


def test_continued_setup_rejects_two_close_players() -> None:
    setup = _setup()
    setup.wrist_dist[:, Slot.BOTTOM] = 0.1

    assert _continued_setup_slot(setup, early_frame=1, candidate_frame=5) is None
