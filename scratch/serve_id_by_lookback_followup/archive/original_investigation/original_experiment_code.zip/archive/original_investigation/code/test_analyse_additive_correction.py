"""Focused tests for the additive trajectory correction policy."""

from dataclasses import replace

from scratch.serve_id_by_lookback_followup.analyse_additive_correction import (
    CorrectionAction,
    CorrectionInput,
    CorrectionReason,
    VisibleStartCategory,
    decide_correction,
)


def _input() -> CorrectionInput:
    """Return one ordinary predecessor row with no supported correction."""
    return CorrectionInput(
        fixture="sset_01",
        video_id=1,
        set_id="set1",
        rally=1,
        fps=30.0,
        accepted_contact_frames=(100, 130),
        baseline_frame=100,
        baseline_category=VisibleStartCategory.VISIBLE_SERVE,
        baseline_player="Top",
        baseline_server="Top",
        h3_first_pre_verdict="unavailable",
        incoming_category=VisibleStartCategory.VISIBLE_SERVE,
        incoming_anchor_frame=130,
        incoming_anchor_rank=2,
        incoming_anchor_player="Bot",
        incoming_predecessor_frame=100,
        incoming_predecessor_rank=1,
        incoming_predecessor_player="Top",
        incoming_predecessor_verdict="not_incoming",
        incoming_admission="ordinary_window",
        incoming_stop_reason="predecessor_admitted_by_ordinary_window",
        incoming_high_shot_start=None,
        incoming_high_shot_end=None,
    )


def test_ordinary_predecessor_is_a_no_op() -> None:
    decision = decide_correction(_input())

    assert decision.correction_action == CorrectionAction.NO_OP
    assert decision.correction_reason == CorrectionReason.ORDINARY_PREDECESSOR_WEAK
    assert decision.corrected_frame == decision.baseline_frame
    assert decision.corrected_server == decision.baseline_server


def test_unavailable_evidence_keeps_the_existing_result() -> None:
    row = replace(
        _input(),
        incoming_category="predecessor_evidence_unavailable",
        incoming_predecessor_verdict="unavailable",
        incoming_admission="none",
        incoming_stop_reason="predecessor_beyond_admission_rules",
    )

    decision = decide_correction(row)

    assert decision.correction_action == CorrectionAction.NO_OP
    assert decision.correction_reason == CorrectionReason.NO_SUPPORTED_CORRECTION
    assert decision.corrected_frame == decision.baseline_frame


def test_high_shot_evidence_that_agrees_is_a_no_op() -> None:
    row = replace(
        _input(),
        incoming_admission="high_shot_oob",
        incoming_stop_reason="predecessor_admitted_by_high_shot_oob",
        incoming_high_shot_start=108,
        incoming_high_shot_end=120,
    )

    decision = decide_correction(row)

    assert decision.correction_action == CorrectionAction.NO_OP
    assert decision.correction_reason == CorrectionReason.STRONG_EVIDENCE_AGREES


def test_high_shot_evidence_can_move_to_a_later_visible_serve() -> None:
    row = replace(
        _input(),
        accepted_contact_frames=(100, 120, 150),
        incoming_anchor_frame=150,
        incoming_anchor_rank=3,
        incoming_predecessor_frame=120,
        incoming_predecessor_rank=2,
        incoming_predecessor_player="Bot",
        incoming_anchor_player="Top",
        incoming_admission="high_shot_oob",
        incoming_stop_reason="predecessor_admitted_by_high_shot_oob",
        incoming_high_shot_start=125,
        incoming_high_shot_end=142,
    )

    decision = decide_correction(row)

    assert decision.correction_action == CorrectionAction.CORRECT
    assert decision.correction_reason == CorrectionReason.HIGH_SHOT_VISIBLE_SERVE
    assert decision.corrected_frame == 120
    assert decision.corrected_category == VisibleStartCategory.VISIBLE_SERVE
    assert decision.corrected_server == "Bot"


def test_existing_incoming_result_survives_weak_new_evidence() -> None:
    row = replace(
        _input(),
        baseline_category=VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT,
        baseline_server="Bot",
        incoming_category="predecessor_evidence_unavailable",
        incoming_predecessor_verdict="unavailable",
    )

    decision = decide_correction(row)

    assert decision.correction_action == CorrectionAction.NO_OP
    assert decision.corrected_category == VisibleStartCategory.FIRST_VISIBLE_POST_SERVE_CONTACT
    assert decision.corrected_server == "Bot"
