#!/usr/bin/env python3
"""Rebuild the derived follow-up tables and headline metrics from frozen CSVs.

This script does not rerun shuttle tracking or contact detection. It uses only
copied frozen evidence in this directory. Ground truth is used only after each
prediction rule has made its decision, for scoring.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
KEY = ["fixture", "video_id", "set_id", "rally"]

CONTACT_EVIDENCE = HERE / "relaxed_contact_evidence.original.csv.gz"
SEARCH_RESULTS = HERE / "relaxed_search_results.original.csv.gz"
BASELINE_RESULTS = HERE / "additive_correction_results.original.csv.gz"

CURRENT_REANALYSIS = HERE / "current_server_reanalysis.csv.gz"
MIN3_OUTPUT = HERE / "minimum_path_3_sensitivity.csv.gz"
NO_RUN_OUTPUT = HERE / "no_usable_pre_run_cases.csv.gz"
APPARENT_RETURN_OUTPUT = HERE / "apparent_return_cases.csv.gz"
METRICS_OUTPUT = HERE / "current_metrics.json"


def other(player: str) -> str:
    return {"Top": "Bot", "Bot": "Top"}[player]


def read_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    contacts = pd.read_csv(CONTACT_EVIDENCE)
    searches = pd.read_csv(SEARCH_RESULTS)
    baseline = pd.read_csv(BASELINE_RESULTS)
    return contacts, searches, baseline


def make_current_reanalysis(
    contacts: pd.DataFrame, searches: pd.DataFrame, baseline: pd.DataFrame
) -> pd.DataFrame:
    # Attach the selected outgoing contact's frozen measurements.
    search = searches.rename(columns={"fps": "fps_search", "span_id": "span_id_search"})
    selected = contacts.rename(columns={"fps": "fps_contact", "span_id": "span_id_contact"})
    selected = selected.rename(columns={"accepted_rank": "selected_evidence_rank"})
    merged = search.merge(
        selected,
        left_on=KEY + ["sequential_selected_rank"],
        right_on=KEY + ["selected_evidence_rank"],
        how="left",
    )

    base_cols = KEY + [
        "fps",
        "baseline_frame",
        "baseline_category",
        "baseline_player",
        "baseline_server",
        "baseline_gt_label",
        "baseline_start_correct",
        "baseline_server_correct",
        "gt_server",
        "gt_stroke_frames",
    ]
    merged = merged.merge(baseline[base_cols], on=KEY, how="left", suffixes=("", "_baseline"))

    standalone_kind: list[str] = []
    direct_server: list[object] = []
    claimed_frame: list[object] = []
    direct_answer: list[bool] = []

    for _, row in merged.iterrows():
        category = row["sequential_category"]
        if category == "visible_serve":
            standalone_kind.append("visible_serve")
            direct_server.append(row["sequential_selected_player"])
            claimed_frame.append(row["sequential_selected_frame"])
            direct_answer.append(True)
        elif category == "first_visible_post_serve_contact":
            standalone_kind.append("apparent_first_return")
            direct_server.append(other(str(row["sequential_selected_player"])))
            claimed_frame.append(row["sequential_selected_frame"])
            direct_answer.append(True)
        elif (
            category == "not_enough_shuttle_trajectory_to_tell"
            and row["sequential_selected_rank"] == 1
            and row.get("pre_path_status") == "no_usable_run"
        ):
            # Derived diagnostic used in the handover: rank-1 has positive
            # outgoing evidence, but no usable pre-contact path. Defaulting
            # that rank-1 hit to the visible serve gives a direct side answer.
            standalone_kind.append("rank1_outgoing_default_visible_serve")
            direct_server.append(row["sequential_selected_player"])
            claimed_frame.append(row["sequential_selected_frame"])
            direct_answer.append(True)
        else:
            standalone_kind.append("unresolved")
            direct_server.append(np.nan)
            claimed_frame.append(np.nan)
            direct_answer.append(False)

    merged["standalone_kind"] = standalone_kind
    merged["standalone_direct_server"] = direct_server
    merged["standalone_claimed_frame"] = claimed_frame
    merged["standalone_has_direct_answer"] = direct_answer
    merged["standalone_direct_server_correct"] = (
        merged["standalone_direct_server"] == merged["gt_server"]
    ) & merged["standalone_has_direct_answer"]

    merged["final_server_with_pr82_fallback"] = np.where(
        merged["standalone_has_direct_answer"],
        merged["standalone_direct_server"],
        merged["baseline_server"],
    )
    merged["final_server_with_pr82_fallback_correct"] = (
        merged["final_server_with_pr82_fallback"] == merged["gt_server"]
    )
    merged["final_changed_vs_pr82"] = (
        merged["final_server_with_pr82_fallback"] != merged["baseline_server"]
    )

    # The selected contact label is valid for the three direct branches above.
    # Unresolved rows deliberately carry no claimed frame.
    merged["claimed_frame_gt_label_at_10"] = np.where(
        merged["standalone_has_direct_answer"],
        merged["tolerance_10_sequential_selected_label"],
        np.nan,
    )

    # Keep the historical column spelling used by the packet where possible.
    merged = merged.drop(columns=["selected_evidence_rank"], errors="ignore")
    merged.to_csv(CURRENT_REANALYSIS, index=False, compression="gzip")
    return merged


def eligible_with_min3(row: pd.Series, prefix: str) -> bool:
    n = row[f"{prefix}_n_frames"]
    gap = row[f"{prefix}_contact_gap"]
    ratio = row[f"{prefix}_largest_step_ratio"]
    decrease = row[f"{prefix}_fitted_decrease_bh"]
    if pd.isna(n) or pd.isna(gap) or pd.isna(ratio) or pd.isna(decrease):
        return False
    return n >= 3 and gap <= 2 and ratio <= 8.0


def make_min3_sensitivity(
    contacts: pd.DataFrame, searches: pd.DataFrame, baseline: pd.DataFrame
) -> pd.DataFrame:
    by_key = {tuple(k): g.sort_values("accepted_rank") for k, g in contacts.groupby(KEY)}
    baseline_by_key = baseline.set_index(KEY)
    rows: list[dict[str, object]] = []

    for _, search in searches.iterrows():
        k = tuple(search[col] for col in KEY)
        group = by_key[k]
        category = "unresolved"
        direct_server: object = np.nan

        for _, contact in group.iterrows():
            if not eligible_with_min3(contact, "post"):
                continue
            if contact["post_fitted_decrease_bh"] > -0.05:
                continue

            if eligible_with_min3(contact, "pre"):
                if contact["pre_fitted_decrease_bh"] >= 0.05:
                    category = "first_visible_post_serve_contact"
                    direct_server = other(str(contact["player"]))
                else:
                    category = "visible_serve"
                    direct_server = contact["player"]
            else:
                category = "pre_contact_unavailable"
            break

        b = baseline_by_key.loc[k]
        gt = b["gt_server"]
        pr82 = b["baseline_server"]
        direct_known = isinstance(direct_server, str)
        final_server = direct_server if direct_known else pr82
        rows.append(
            {
                **dict(zip(KEY, k)),
                "min_path_3_category": category,
                "min_path_3_direct_server": direct_server,
                "min_path_3_direct_server_correct": bool(direct_known and direct_server == gt),
                "min_path_3_final_server_with_pr82_fallback": final_server,
                "min_path_3_final_correct": bool(final_server == gt),
                "min_path_3_changed_vs_pr82": bool(final_server != pr82),
                "gt_server": gt,
                "pr82_server": pr82,
            }
        )

    out = pd.DataFrame(rows)
    out.to_csv(MIN3_OUTPUT, index=False, compression="gzip")
    return out


def add_immediate_predecessor_fields(
    rows: pd.DataFrame, contacts: pd.DataFrame, include_player_and_status: bool
) -> pd.DataFrame:
    contacts_by_key = {tuple(k): g.set_index("accepted_rank") for k, g in contacts.groupby(KEY)}
    extra: list[dict[str, object]] = []

    for _, row in rows.iterrows():
        rank = row["sequential_selected_rank"]
        item: dict[str, object] = {}
        if pd.isna(rank) or rank <= 1:
            if include_player_and_status:
                item["has_immediate_predecessor"] = False
            for col in [
                "immediate_predecessor_frame",
                "immediate_predecessor_rank",
                "immediate_predecessor_player",
                "immediate_predecessor_pre_verdict",
                "immediate_predecessor_pre_path_status",
                "immediate_predecessor_post_path_status",
                "immediate_predecessor_credible_outgoing",
                "accepted_gap_base30",
            ]:
                item[col] = np.nan
            extra.append(item)
            continue

        k = tuple(row[col] for col in KEY)
        prev_rank = int(rank) - 1
        prev = contacts_by_key[k].loc[prev_rank]
        if include_player_and_status:
            item["has_immediate_predecessor"] = True
        item["immediate_predecessor_frame"] = prev["contact_frame"]
        item["immediate_predecessor_rank"] = prev_rank
        item["immediate_predecessor_player"] = prev["player"]
        item["immediate_predecessor_pre_verdict"] = prev["pre_verdict"]
        item["immediate_predecessor_pre_path_status"] = prev["pre_path_status"]
        item["immediate_predecessor_post_path_status"] = prev["post_path_status"]
        item["immediate_predecessor_credible_outgoing"] = prev["credible_outgoing"]
        fps = float(row["fps_search"])
        item["accepted_gap_base30"] = (
            float(row["sequential_selected_frame"]) - float(prev["contact_frame"])
        ) * 30.0 / fps
        extra.append(item)

    ext = pd.DataFrame(extra, index=rows.index)
    return pd.concat([rows, ext], axis=1)


def make_diagnostic_subsets(
    reanalysis: pd.DataFrame, contacts: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame]:
    no_run = reanalysis[
        (reanalysis["sequential_category"] == "not_enough_shuttle_trajectory_to_tell")
        & (reanalysis["pre_path_status"] == "no_usable_run")
    ].copy()
    no_run = add_immediate_predecessor_fields(no_run, contacts, include_player_and_status=False)
    # Match the narrower historical table: omit the player/pre-path-status helper fields.
    no_run = no_run.drop(
        columns=["immediate_predecessor_player", "immediate_predecessor_pre_path_status"],
        errors="ignore",
    )
    no_run.to_csv(NO_RUN_OUTPUT, index=False, compression="gzip")

    apparent = reanalysis[reanalysis["standalone_kind"] == "apparent_first_return"].copy()
    apparent = add_immediate_predecessor_fields(apparent, contacts, include_player_and_status=True)
    apparent.to_csv(APPARENT_RETURN_OUTPUT, index=False, compression="gzip")
    return no_run, apparent


def run_companion_scripts() -> tuple[pd.DataFrame, pd.DataFrame]:
    for name in ["recompute_preferred_server_rule.py", "recompute_server_id_cascade.py"]:
        subprocess.run([sys.executable, str(HERE / name)], check=True, stdout=subprocess.DEVNULL)
    preferred = pd.read_csv(HERE / "server_id_preferred_170.csv.gz")
    cascade = pd.read_csv(HERE / "server_id_cascade_171.csv.gz")
    return preferred, cascade


def build_metrics(
    reanalysis: pd.DataFrame,
    min3: pd.DataFrame,
    preferred: pd.DataFrame,
    cascade: pd.DataFrame,
    baseline: pd.DataFrame,
) -> dict[str, object]:
    population = len(baseline)
    pr82_correct = int(baseline["baseline_server_correct"].astype(bool).sum())
    pr82_visible = int(baseline["baseline_start_correct"].astype(bool).sum())

    direct = reanalysis["standalone_has_direct_answer"].astype(bool)
    derived_160_coverage = int(direct.sum())
    derived_160_correct = int(reanalysis.loc[direct, "standalone_direct_server_correct"].astype(bool).sum())
    old_170 = int(reanalysis["final_server_with_pr82_fallback_correct"].astype(bool).sum())
    min3_correct = int(min3["min_path_3_final_correct"].astype(bool).sum())

    preferred_server = int(preferred["server_correct"].astype(bool).sum())
    preferred_temporal = int(preferred["temporal_slot_correct"].astype(bool).sum())
    preferred_joint = int(preferred["joint_temporal_and_server_correct"].astype(bool).sum())
    preferred_serve_frames = int(
        ((preferred["temporal_claim"] == "serve") & (preferred["temporal_gt_label_at_10"] == "contact_1")).sum()
    )

    cascade_correct = int(cascade["predicted_server_correct"].astype(bool).sum())
    branch_counts: dict[str, dict[str, int]] = {}
    for branch, group in cascade.groupby("prediction_branch"):
        branch_counts[str(branch)] = {
            "count": int(len(group)),
            "correct": int(group["predicted_server_correct"].astype(bool).sum()),
        }

    changed = cascade[cascade["changed_vs_pr82"].astype(bool)]
    fixes = int(
        ((changed["predicted_server_correct"].astype(bool)) & (~changed["pr82_server_correct"].astype(bool))).sum()
    )
    damages = int(
        ((~changed["predicted_server_correct"].astype(bool)) & (changed["pr82_server_correct"].astype(bool))).sum()
    )

    # Temporal comparison for the 171 sensitivity uses the same contact interpretation
    # as the selected outgoing branch; on fallback it treats rank 1 as return only for
    # the relaxed rank-1 incoming branch, otherwise as serve.
    search = pd.read_csv(SEARCH_RESULTS)
    contact = pd.read_csv(CONTACT_EVIDENCE)
    rank1 = contact[contact["accepted_rank"] == 1][KEY + ["player", "pre_verdict"]]
    tmp = search.merge(rank1, on=KEY, how="left").merge(
        baseline[KEY + ["baseline_frame", "baseline_gt_label"]], on=KEY, how="left"
    )
    sens_claim: list[str] = []
    sens_label: list[str] = []
    for _, row in tmp.iterrows():
        if row["sequential_category"] == "visible_serve":
            sens_claim.append("serve")
            sens_label.append(row["tolerance_10_sequential_selected_label"])
        elif row["sequential_category"] == "first_visible_post_serve_contact":
            sens_claim.append("return")
            sens_label.append(row["tolerance_10_sequential_selected_label"])
        elif row["pre_verdict"] == "incoming":
            sens_claim.append("return")
            sens_label.append(row["baseline_gt_label"])
        else:
            sens_claim.append("serve")
            sens_label.append(row["baseline_gt_label"])
    sens_temporal_correct = [
        (c == "serve" and lab == "contact_1") or (c == "return" and lab == "contact_2")
        for c, lab in zip(sens_claim, sens_label)
    ]
    cascade_server_correct = cascade["predicted_server_correct"].astype(bool).tolist()
    sens_joint = sum(a and b for a, b in zip(sens_temporal_correct, cascade_server_correct))
    sens_serve_frames = sum(c == "serve" and lab == "contact_1" for c, lab in zip(sens_claim, sens_label))

    return {
        "arc_rescue_demo": {
            "claimed_full_19_path_result": False,
            "needs_original_samples_for_all_19": True,
            "rescued_errors": 2,
            "supplied_error_paths": 8,
        },
        "branch_counts": branch_counts,
        "changed_vs_pr82": int(len(changed)),
        "damages_vs_pr82": damages,
        "fixes_vs_pr82": fixes,
        "historical_171_sensitivity_correct": cascade_correct,
        "historical_reference": {
            "derived_160_correct_server_sides": derived_160_correct,
            "derived_160_coverage": derived_160_coverage,
            "minimum_path_3_old_composition_correct": min3_correct,
            "outgoing_plus_pr82_fallback_server_correct": old_170,
            "pr82_visible_start_correct": pr82_visible,
        },
        "population": population,
        "pr82_server_correct": pr82_correct,
        "preferred_correct_visible_serve_frame_claims": preferred_serve_frames,
        "preferred_joint_temporal_and_server_correct": preferred_joint,
        "preferred_server_rule": "outgoing-selected inference; PR #82 fallback when unresolved",
        "preferred_server_rule_correct": preferred_server,
        "preferred_temporal_slot_correct": preferred_temporal,
        "rank1_fallback_correct_visible_serve_frame_claims": int(sens_serve_frames),
        "rank1_fallback_joint_temporal_and_server_correct": int(sens_joint),
        "rank1_fallback_sensitivity_correct": cascade_correct,
        "rank1_fallback_temporal_slot_correct": int(sum(sens_temporal_correct)),
    }


def main() -> None:
    contacts, searches, baseline = read_inputs()
    reanalysis = make_current_reanalysis(contacts, searches, baseline)
    min3 = make_min3_sensitivity(contacts, searches, baseline)
    no_run, apparent = make_diagnostic_subsets(reanalysis, contacts)
    preferred, cascade = run_companion_scripts()
    metrics = build_metrics(reanalysis, min3, preferred, cascade, baseline)
    METRICS_OUTPUT.write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print(f"PR #82 server: {metrics['pr82_server_correct']}/{metrics['population']}")
    print(f"Preferred server rule: {metrics['preferred_server_rule_correct']}/{metrics['population']}")
    print(f"Rank-1 fallback sensitivity: {metrics['rank1_fallback_sensitivity_correct']}/{metrics['population']}")
    print(f"Derived direct coverage: {metrics['historical_reference']['derived_160_coverage']}/{metrics['population']}")
    print(f"Minimum-path-3 sensitivity: {metrics['historical_reference']['minimum_path_3_old_composition_correct']}/{metrics['population']}")
    print(f"no_usable_run rows: {len(no_run)}")
    print(f"apparent-return rows: {len(apparent)}")
    print(METRICS_OUTPUT)


if __name__ == "__main__":
    main()
