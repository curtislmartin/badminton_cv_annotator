# What happened

## 1. PR #82 found a useful local server cue

The older released server rule fitted an alternating player rhythm across the accepted contact sequence.

On the 239 one-to-one development rallies, that rule gets **124 server sides right**.

Simply taking the player at the earliest accepted contact improves that to **152/239**.

PR #82 then adds one local motion question:

> Is the shuttle moving toward that player immediately before the earliest accepted contact?

If yes, PR #82 treats the contact as the first return and assigns the serve to the other side.

If no incoming trigger is found, the earliest-contact side remains the server.

That raises server-side accuracy to **163/239**.

PR #82 therefore showed that local shuttle motion can improve server identification without the alternating-fit heuristic.

## 2. PR #82's server score hides timing mistakes

PR #82 gets the visible-start interpretation right in **125/239** rallies.

That consists of:

- 115 correctly identified visible serves;
- 10 correctly identified first returns.

Server side is correct more often: **163/239**.

The overlap is:

| Visible-start interpretation | Server side | Rallies |
| --- | --- | ---: |
| Correct | Correct | 96 |
| Wrong | Correct | 67 |
| Correct | Wrong | 29 |
| Wrong | Wrong | 47 |

The 67 “wrong start, right server” cases explain much of the gap between 125 and 163.

Most are early accepted impulses on the eventual server's side. The timing is wrong, but the side happens to be right.

Among 58 wrong-start/right-server cases whose claimed frame matches no GT contact at ±10, **54 occur before GT contact 1**.

This means server-ID accuracy and exact serve timing must be scored separately.

## 3. The follow-up was meant to extend the PR #82 idea globally

The intended question was not merely “can we find contact 1 exactly?”

It was:

> Can we use the whole accepted sequence and local shuttle motion to identify the server without the old alternating-fit rule?

A natural extension was to stop trusting the first accepted impulse automatically.

Instead, search for the earliest contact that has positive evidence of a real hit: credible outgoing shuttle motion after the contact.

Then inspect the shuttle motion before that selected contact.

```text
not incoming before + outgoing after
    → serve-like contact
    → this player served

incoming before + outgoing after
    → return-like contact
    → the other player served
```

This is a GT-free server inference.

## 4. The first outgoing-contact experiment was too strict

The first version used the wider recurrence guard and a strict jump-ratio limit.

It skipped the first accepted contact in 218/239 rallies.

The median selected contact was rank 3. Some searches ran much later into the rally.

That made it a poor exact-opener rule.

At ±10 it fixed 16 visible starts and damaged 34.

The main failure was not the incoming classifier itself. The search often reached the wrong rally contact before applying that classifier.

## 5. The follow-up then made local trajectory evidence less brittle

Two measurement settings were relaxed:

- recurrence buffer: 15 source frames → **3 source frames** around the recurrence core;
- largest-step ratio limit: 4.0 → **8.0**.

The minimum usable path stayed at **5 frames**.

The incoming/outgoing threshold stayed at **0.05 body heights**.

These settings are called **relaxed trajectory evidence** in this packet.

The original package used an opaque shorthand for the same settings. That shorthand is kept only in `06_TRACEABILITY.md`.

## 6. The relaxed outgoing search contains useful server information

With the relaxed evidence, the search finds some outgoing-positive contact in **234/239** rallies.

It can classify the selected contact as serve-like or return-like in **91/239**:

- 23 serve-like;
- 68 return-like.

Those 91 direct server answers are correct in **60/91** rallies.

The original report mostly judged this search as an exact visible-opener replacement. On that target it is weak.

But as a server-ID signal it is useful.

Using PR #82 only when the outgoing search cannot classify a server gives **170/239** correct server sides.

That re-score is GT-free at decision time. GT is joined only afterward for scoring.

## 7. The earlier 160/239 figure was coverage, not correctness

A later diagnostic made one implicit fallback explicit.

There are 69 cases where:

- the selected outgoing-positive contact is rank 1;
- no usable pre-contact run exists.

A GT-free default can treat rank 1 as the serve-like side in those cases.

Adding those 69 to the 91 measured decisions gives **160 direct decisions**.

Only **120/160** of those direct server sides are correct.

So 160 is a coverage count, not a correctness count.

That diagnostic helped explain the evidence, but it does not need to be a separate stage in the final server-ID rule.

## 8. The preferred complete rule is the 170/239 composition

The cleanest rule to carry forward is:

```text
A. Find the earliest outgoing-positive accepted contact.

B. If its pre-contact motion is measurable:
       incoming     → other side served
       not incoming → selected-contact side served

C. Otherwise keep the PR #82 server answer.
```

This predicts a server for all 239 rallies and gets **170/239** server sides right on the development set.

A nearby sensitivity replaces the PR #82 fallback with another relaxed rank-1 motion check. It reaches **171/239** server sides, but its sole extra side-correct result changes a true serve into a false return interpretation. Temporal-slot correctness falls from 132/239 to 131/239, while joint temporal-and-server correctness stays 117/239.

The extra point is not enough reason to carry the weaker fallback forward. The 170 rule is simpler and better aligned with the physical interpretation.

## 9. The follow-up also tested predecessor timing and high-shot gaps

A separate search started from an incoming contact and inspected its immediately preceding accepted contact.

Ordinary accepted-contact proximity was weak evidence.

The ordinary ≤60-base-30-frame rule admitted 196 predecessors. Thirty-nine had measured not-incoming motion, but only 3/39 matched GT contact 1 at ±10.

A measured high-shot-out-of-bounds exception was much cleaner.

It admitted five predecessors using a fixed ±12-base-30-frame endpoint allowance. All five matched GT contact 1 at ±10.

That is a useful narrow state, but all five examples come from one set.

It is not a broad serve reconstruction rule.

## 10. Pose and alternation did not solve the remaining timing problem

A broad serve-setup wrist-proximity rule changed 138 starts.

It fixed 22 and damaged 63.

A stricter same-player continuation rule fired twice: one fix and one damage.

Other combinations of alternation, later incoming evidence, and predecessor timing had the same problem.

They could say that a sequence looked suspicious.

They could not reliably prove which accepted impulse was the serve.

## 11. The exact serve-timing problem is limited by the observation itself

The local path feature is player-relative distance in a monocular 2D image.

The real shuttle moves in 3D.

A high or arcing shot can move closer or farther in depth while its projected 2D distance changes little, changes direction, or even appears to move the opposite way.

So a long-range “physical continuity” test based on this scalar 2D distance would overstate what the data can prove.

That is why another large round of predecessor/continuity heuristics is not the obvious next experiment.

The previous series has already explored much of that space.

## 12. There is one small measurement refinement worth trying

The current PR #82 incoming rule compresses the whole path into one robust linear trend.

That can be misleading when the observed 2D path itself has a clear turn.

A narrow refinement can preserve the current rule and only revisit a current `not incoming` verdict when the path contains a well-supported arc.

The prototype does this:

1. keep every existing incoming call;
2. fit a quadratic only to decide whether there is a real interior turning point;
3. if the turn is well supported, split the path there;
4. fit robust early and late slopes;
5. rescue the verdict to incoming only when the early limb recedes and the late limb approaches by at least 0.05 BH.

On the eight supplied PR #82 mistakes, the prototype rescues two missed first returns.

It leaves the four existing false-return calls unchanged.

This is intentionally a recall rescue, not a new global classifier.

The demonstration uses points digitised from the supplied error figure. It still needs to be rerun on the original per-frame samples for all 19 labelled usable paths.

## 13. The current conclusion

The trajectory/contact heuristic space has already been explored quite extensively.

The main unfinished server-ID question is now validation, not another large heuristic search.

The **preferred 170/239 GT-free server rule** should be frozen and tested on unseen rallies.

The **arc-aware rescue** is the only obvious small local measurement change that currently looks worth the effort.

If exact serve timing needs a much larger gain, it probably needs a new observation such as racket or hitting-arm motion rather than more rules over the same 2D distance signal.
