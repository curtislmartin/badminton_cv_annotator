# Source and name traceability

This packet uses plain names in the narrative.

The original package used several opaque labels. They are listed here only so the rewritten findings can be traced back to the source files.

## Old term to plain term

| Original term | Plain term in this packet | Exact meaning |
| --- | --- | --- |
| `H3` | 3-frame recurrence buffer | Three literal source frames on each side of the recurrence core. |
| `R8` | 8.0 largest-step limit | Local path remains eligible when `largest_step_ratio <= 8.0`. |
| `H3/R8` | relaxed trajectory evidence | 3-frame recurrence buffer + 8.0 step-ratio limit. Direction threshold stays ±0.05 BH. |
| `H15/R4` | strict trajectory evidence | Wider 15-frame recurrence buffer + 4.0 step-ratio limit. |
| Search A / sequential | outgoing-contact search | Earliest accepted contact with credible outgoing motion, then classify its pre-motion. |
| Search B / incoming-only | incoming-anchor predecessor search | Earliest incoming accepted contact, then inspect its immediate predecessor. |
| `high_shot_oob` | measured high-shot long-gap state | Existing measured state that can admit a predecessor across a long accepted-contact gap. |
| serve-setup continuation | serve-setup wrist evidence | Existing player-presence / shuttle-to-wrist state measured at accepted contacts. |

## Original files

| File | Main content |
| --- | --- |
| `originals/PR82_CONTEXT.md` | PR #82 context and intended server-ID question. |
| `originals/report.md` | First strict outgoing-contact experiment. |
| `originals/h3_r8_report.md` | Relaxed trajectory searches, high-shot correction, pose follow-up. |
| `originals/mechanisms.md` | Mechanism status tables. |
| `originals/evidence.md` | Measurement details, counts, checks, provenance. |
| `originals/Scope.md` | Original follow-up scope. |
| `originals/01_LAUNCH_ACCEPTED_CONTACT_TRACE.md` | Earlier state-machine plan. |
| `originals/02_LAUNCH_H3_R8_DUAL_SEARCH.md` | Relaxed-evidence dual-search specification. |
| `originals/serve_id_by_lookback_followup.tar` | Full original supplied package. |

## Rewritten evidence files

| File | Use |
| --- | --- |
| `supporting/relaxed_contact_evidence.original.csv.gz` | Per-accepted-contact frozen relaxed evidence. |
| `supporting/relaxed_search_results.original.csv.gz` | Frozen outgoing and predecessor search results. |
| `supporting/additive_correction_results.original.csv.gz` | PR #82 baseline server + GT scoring fields used after inference. |
| `supporting/server_id_preferred_170.csv.gz` | Preferred reconstructed 170-rule result. |
| `supporting/server_id_cascade_171.csv.gz` | Rank-1 fallback sensitivity result. |
| `supporting/recompute_server_id_cascade.py` | Rebuilds the current rule and score from the frozen source tables. |
| `supporting/minimum_path_3_sensitivity.csv.gz` | Three-frame path sensitivity. |
| `supporting/arc_rescue_demo.py` | Reproduces the limited arc-aware demonstration from digitised figure points. |
| `figures/trend_rule_errors.original.png` | Supplied eight-error PR #82 plot. |
| `figures/arc_rescue_annotated.png` | Annotated arc decomposition and prototype verdicts. |

## Interpretation change

The original follow-up's broad negative conclusion mainly applies to **exact visible-start reconstruction with a high precision bar**.

It should not be read as proof that the PR #82 family cannot improve server identification.

Re-scoring the already-frozen GT-free evidence gives a preferred **170/239** development server-ID result: use the outgoing-selected inference when available, otherwise keep PR #82. A 171/239 rank-1 fallback sensitivity is retained only for comparison.

The other important change is in the proposed future work.

A long-range physical-continuity experiment is no longer the recommended main next step. The existing feature is a monocular 2D projection, and the previous experiment series has already explored much of the predecessor/timing heuristic space.

The next useful tests are holdout validation of the server-ID rule and exact evaluation of the small arc-aware rescue on the original path samples.
