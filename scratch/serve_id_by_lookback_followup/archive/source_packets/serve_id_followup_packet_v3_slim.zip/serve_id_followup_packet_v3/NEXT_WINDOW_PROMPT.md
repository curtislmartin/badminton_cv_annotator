# Fresh-window prompt

Read `README.md` first, then `01_NARRATIVE.md` and `02_CURRENT_EVIDENCE.md`.

The primary objective is **server-side identification**, not exact opener-frame recovery.

The preferred frozen development rule is:

```text
find earliest outgoing-positive accepted contact

if its pre-motion is measurable:
    incoming     → other side served
    not incoming → selected-contact side served
else:
    keep the PR #82 server answer
```

On the current 239-rally development set this scores **170/239 server sides correct**.

A nearby rank-1 fallback sensitivity scores 171/239, but its only extra side-correct result loses a correct temporal interpretation. Keep it as a sensitivity result, not the default rule.

Do not use GT to choose any branch, threshold, contact, or verdict. Join GT only after the prediction file is frozen.

Keep the existing local settings fixed unless the task explicitly says otherwise:

```text
recurrence buffer        3 source frames
largest-step ratio       <= 8.0
minimum usable path      5 frames
local path window        30 base-30fps frames
maximum contact gap      2 base-30fps frames
incoming threshold       +0.05 BH
outgoing threshold       -0.05 BH
```

Do not lower the path minimum to three frames. The existing sensitivity made the result worse.

There is one small new candidate measurement refinement in `03_ARC_AWARE_RESCUE.md`.

It keeps every existing incoming call and only rescues a current `not incoming` call when a well-supported interior arc has an early receding limb and a late approaching limb with at least 0.05 BH fitted late closure.

The supplied eight-error demonstration rescues two missed returns, but the other 11 labelled usable paths have not yet been run. Do not claim a net 19-path improvement until the original samples are evaluated.

Recommended work order:

1. If unseen rally data is available, validate the preferred frozen 170-rule without retuning it.
2. If the original PR #82 path samples are available, run the frozen arc-aware rescue on all 19 labelled usable paths.
3. Keep server side and exact timing as separate outputs.
4. Do not make long-range 2D trajectory continuity the main experiment. Monocular projected distance cannot reliably reconstruct 3D shuttle arcs.
5. If exact serve timing still needs a large improvement, prefer a genuinely new local observation such as racket or hitting-arm evidence.

Communication requirements:

- lead with the global result and evaluation;
- use simple words when simple words work;
- avoid project-management language;
- use progressive disclosure;
- keep one main idea per sentence and paragraph where practical;
- preserve technical detail, but place it below the explanation rather than mixing everything together.
