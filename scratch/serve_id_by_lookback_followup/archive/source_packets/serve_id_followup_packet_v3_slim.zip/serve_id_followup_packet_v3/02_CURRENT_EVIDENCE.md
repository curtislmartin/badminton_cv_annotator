# What the current data supports

## 1. Server-side results

All headline results below use the same 239 one-to-one development rallies.

| Rule | Correct server sides |
| --- | ---: |
| Released alternating fit | 124/239 |
| Earliest accepted-contact player | 152/239 |
| PR #82 direct incoming correction | 163/239 |
| **Preferred outgoing-search + PR #82 fallback** | **170/239** |
| Rank-1 fallback sensitivity | 171/239 |

Both rules are GT-free at runtime. Ground truth is used only after predictions are frozen.

The preferred 170 rule uses the outgoing-selected serve/return inference when that inference is available. Otherwise it keeps PR #82.

The 171 sensitivity differs on only one rally. It gains the server side there by changing a temporally correct serve interpretation into an incorrect return interpretation.

| Comparison | Preferred 170 | 171 sensitivity |
| --- | ---: | ---: |
| Correct server side | 170/239 | 171/239 |
| Correct temporal slot | **132/239** | 131/239 |
| Correct visible serve-frame claims | **97** | 96 |
| Temporal slot + server both correct | 117/239 | 117/239 |

The simpler 170 rule is therefore the one to carry forward.

## 2. PR #82 timing and server side are different scores

PR #82 makes:

- 224 visible-serve calls;
- 15 first-return calls.

At ±10 base-30fps frames:

| PR #82 call | GT contact 1 | GT contact 2 | Later | Unmatched |
| --- | ---: | ---: | ---: | ---: |
| Visible serve | 115 | 9 | 4 | 96 |
| First return | 4 | 10 | 0 | 1 |

So PR #82 gets the visible-start interpretation right in **125/239** rallies.

Its server side is right in **163/239**.

The overlap is:

| Visible-start interpretation | Server side | Rallies |
| --- | --- | ---: |
| Correct | Correct | 96 |
| Wrong | Correct | 67 |
| Correct | Wrong | 29 |
| Wrong | Wrong | 47 |

Among the 58 wrong-start/right-server frames that match no GT contact at ±10, 54 happen before GT contact 1.

That is the clearest evidence that premature accepted impulses can give the right side for the wrong temporal reason.

## 3. Timing when PR #82 is genuinely right

For the 115 correct visible-serve calls:

- median absolute timing error: **3.6 base-30fps frames**;
- 83/115 are within ±5;
- all 115 are within ±10 by definition.

For the 10 correct first-return calls:

- median absolute timing error: **1.6 base-30fps frames**;
- all 10 are within ±5.

When PR #82 truly finds contact 2, its frame location is quite tight.

## 4. Relaxed outgoing-contact evidence

The follow-up's more permissive local trajectory measurement uses:

```text
recurrence buffer              3 source frames around recurrence core
largest-step ratio             <= 8.0
minimum usable path            5 frames
local window                   30 base-30fps frames
maximum gap to contact         2 base-30fps frames
incoming                       fitted decrease >= +0.05 BH
outgoing                       fitted decrease <= -0.05 BH
```

The outgoing search finds an outgoing-positive contact in **234/239** rallies.

Its selected-contact categories are:

| Category | Rallies |
| --- | ---: |
| Incoming before selected hit | 68 |
| Not incoming before selected hit | 23 |
| Pre-contact trajectory unavailable | 143 |
| No outgoing-positive accepted contact | 5 |

So the strong selected-contact inference covers 91 rallies.

It gets 60/91 server sides right.

## 5. The old 160/239 diagnostic

A previous analysis explicitly promoted 69 cases where:

- the selected outgoing-positive contact is rank 1;
- no usable pre-contact run exists.

That produced 160 direct decisions:

| Direct decision type | Rallies | Correct server sides |
| --- | ---: | ---: |
| Measured serve-like | 23 | 15 |
| Rank-1/no-run default | 69 | 60 |
| Measured return-like | 68 | 45 |
| **Total** | **160** | **120** |

This remains useful diagnostic information.

It should not be described as “160 correct serve frames.”

The 171 sensitivity does not need this as a separate algorithmic stage.

## 6. The 68 selected incoming/outgoing contacts

These are the strongest “return-like” calls made by the expanded search.

At ±10, their selected frames are:

| Actual GT relation | Rallies |
| --- | ---: |
| Contact 2 | 34 |
| Later contact | 23 |
| Unmatched | 8 |
| Contact 1 | 3 |

The inferred server side is correct in **45/68**.

Among the 34 cases that really are contact 2, **33/34** infer the correct server side.

So the opposite-side inference is strong once contact 2 is actually found.

The difficult step is knowing whether an incoming/outgoing hit is contact 2 or a later rally stroke.

## 7. Predecessor timing is not enough

Fourteen of the 68 return-like anchors are rank 1 and have no earlier accepted contact.

The other 54 have an immediate accepted predecessor.

All 54 predecessors fail the standalone outgoing-positive predicate, as expected: the anchor was chosen as the earliest outgoing-positive contact.

Only six predecessors have both:

- ordinary gap ≤60 base-30fps frames;
- measured `not incoming` pre-motion.

Only **1/6** is GT contact 1 at ±10.

So ordinary timing plus a not-incoming predecessor is not a reliable serve locator.

## 8. The measured high-shot long-gap state

A separate predecessor search allowed a long gap when a measured high-shot-out-of-bounds state lay between two adjacent accepted contacts and both contacts were within ±12 base-30fps frames of the corresponding state endpoints.

Five predecessors were admitted through that state.

All **5/5** match GT contact 1 at ±10.

All five come from one set, so this is promising but narrow evidence.

For the specific 68 return-like anchors from the outgoing-first search, none of their immediate predecessor links qualifies for the existing ±12 high-shot bridge.

## 9. No usable pre-contact run

There are 90 selected outgoing-positive contacts whose pre-contact status is `no_usable_run`.

Selected accepted-contact rank:

| Rank | Rallies |
| ---: | ---: |
| 1 | 69 |
| 2 | 15 |
| 3 | 3 |
| 6 | 1 |
| 7 | 1 |
| 10 | 1 |

The 69 rank-1 cases contain:

- 57 GT contact-1 matches at ±10;
- 60 correct server sides;
- 51 with both contact 1 and the correct server side.

The frozen table does not preserve the frame-by-frame reason why the usable mask is empty.

A split such as TrackNet missing vs recurrence guard vs missing player measurement requires the original frame-level arrays or an exported reason mask.

## 10. Three-frame path sensitivity

The tarball contains enough saved measurements to lower the minimum usable path from five frames to three without loading the original shuttle arrays.

That change makes the server rule worse.

| Result | Minimum 5 | Minimum 3 |
| --- | ---: | ---: |
| Strong direct answers | 91 | 96 |
| Strong direct answers correct | 60 | 60 |
| Earlier final score with PR #82 fallback | **170** | **166** |
| Fixes vs PR #82 | 20 | 20 |
| Damages vs PR #82 | 13 | 17 |

The five-frame minimum should stay.

## 11. Arc-aware rescue: current evidence

The original PR #82 audit has 19 labelled usable unique-truth paths under its main source-quality rule.

The 0.05-BH trend rule makes eight mistakes among those 19.

The supplied error figure contains those eight mistakes only.

A prototype arc-aware rescue was built from that figure:

- existing incoming calls are never overturned;
- only existing `not incoming` calls are reconsidered;
- a quadratic is used only to find a well-supported interior turn;
- robust early and late slopes are then fitted;
- rescue occurs only when the early limb recedes and the late limb approaches by at least 0.05 BH.

On the eight supplied errors, it fixes:

- `sset_15 set2 rally 6`;
- `sset_01 set3 rally 13`.

It leaves the other six mistakes unchanged.

This is **not yet a measured 13/19 result** because the other 11 labelled usable paths are not present in the supplied image.

The exact frozen rule must be rerun on the original path samples before claiming a net gain.

## 12. What the tarball can still answer

The tarball is sufficient to:

- reproduce the 170/239 composition;
- reproduce the 171/239 rank-1 fallback sensitivity;
- reproduce the 160/239 diagnostic coverage analysis;
- reproduce the three-frame path sensitivity;
- inspect frozen accepted-contact rank, player, pre/post path status, fitted direction, and jump ratio;
- apply the already-measured high-shot state and ±12 endpoint rule to adjacent accepted contacts.

The tarball is not sufficient to:

- rerun the arc-aware rule on the original per-frame PR #82 path samples;
- explain every `no_usable_run` at frame level;
- add a new RGB/racket-motion contact verifier;
- change the high-shot detector itself.
