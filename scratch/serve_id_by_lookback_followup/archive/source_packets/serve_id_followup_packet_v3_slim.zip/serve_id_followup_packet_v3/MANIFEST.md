# Packet contents

## Start here

- `README.md` — global conclusion.
- `01_NARRATIVE.md` — chronological story.
- `02_CURRENT_EVIDENCE.md` — current measured results.
- `03_ARC_AWARE_RESCUE.md` — limited curved-path refinement.
- `04_NEXT_STEPS.md` — the two worthwhile next tests.
- `05_TECHNICAL_REFERENCE.md` — detailed thresholds, counts, and method boundaries.
- `06_TRACEABILITY.md` — mapping back to original names and files.
- `NEXT_WINDOW_PROMPT.md` — compact fresh-window instructions.

## Figures

- `figures/trend_rule_errors.original.png` — supplied eight-error PR #82 figure.
- `figures/arc_rescue_annotated.png` — annotated arc-aware demonstration.

## Supporting calculations

- `supporting/recompute_preferred_server_rule.py` — reproduces the preferred 170/239 server rule.
- `supporting/server_id_preferred_170.csv.gz` — per-rally output from the preferred rule.
- `supporting/recompute_server_id_cascade.py` — reproduces the 171/239 rank-1 fallback sensitivity.
- `supporting/server_id_cascade_171.csv.gz` — per-rally output from that sensitivity.
- `supporting/arc_rescue_demo.py` — reproduces the limited arc-aware demonstration from digitised figure points.
- `supporting/arc_rescue_rule_demo.md` — exact demo rule and per-path result table.
- copied original frozen evidence CSV/JSON files used by the calculations.

## Original material

`originals/` preserves the source Markdown reports and the supplied source tarball in the full packet.

The slim archive omits the nested source tarball but keeps the original Markdown reports and frozen evidence tables needed for the reconstructed calculations.
