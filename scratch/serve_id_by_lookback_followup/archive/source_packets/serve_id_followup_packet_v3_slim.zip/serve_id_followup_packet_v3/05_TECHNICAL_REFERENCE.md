# Technical reference

This file keeps the details that are intentionally omitted from the first three documents.

## Population

The frozen development population contains 239 one-to-one rallies:

- `sset_01`: 104;
- `sset_15`: 84;
- `sset_21`: 51.

Stable key:

```text
(fixture, video_id, set_id, rally)
```

The 239 rows are selected through a GT-derived one-to-one rally/span crosswalk.

That crosswalk defines the evaluation population.

Search decisions themselves are built from a GT-free projection and frozen before GT is joined.

## PR #82 reference values

Server-side comparison:

| Rule | Correct server sides |
| --- | ---: |
| Released alternating-player fit | 124/239 |
| Earliest accepted contact player | 152/239 |
| PR #82 direct incoming-motion rule | **163/239** |
| PR #82 prepend + alternating refit | 159/239 |

PR #82 direct incoming calls occur in 15 rallies.

Server side is correct in 13/15 of those 15.

The remaining 224 rows keep the earliest-contact-side interpretation.

## PR #82 visible-start labels at ±10

| PR #82 category | Contact 1 | Contact 2 | Later | Unmatched |
| --- | ---: | ---: | ---: | ---: |
| Visible serve | 115 | 9 | 4 | 96 |
| First visible post-serve contact | 4 | 10 | 0 | 1 |

Correct visible-start interpretations:

```text
115 visible serves
+10 first returns
=125/239
```

Start/server contingency:

```text
start correct, server correct    96
start wrong,   server correct    67
start correct, server wrong      29
start wrong,   server wrong      47
```

## PR #82 timing when contact ordinal is correct

Correct visible serves:

```text
n                                  115
median absolute error              3.6 base-30fps frames
within ±5                           83
within ±10                         115
```

Correct first returns:

```text
n                                   10
median absolute error              1.6 base-30fps frames
within ±5                           10
within ±10                          10
```

## Raw earliest-contact alignment at ±10

| Earliest accepted frame | Rallies |
| --- | ---: |
| GT contact 1 | 119 |
| GT contact 2 | 19 |
| Later GT contact | 4 |
| Unmatched | 97 |

These are frame-alignment labels, not server-side scores.

## Local trajectory measurement

The trajectory measurement uses shuttle-to-player distance normalised by apparent player body height.

A robust fitted decrease is derived from the local distance trend.

Direction classification:

```text
incoming     fitted_decrease_bh >= +0.05
outgoing     fitted_decrease_bh <= -0.05
```

The contact frame itself is excluded from both local sides.

The pre-contact search window is:

```text
[contact - lookback, contact)
```

The post-contact search window is:

```text
(contact, contact + lookahead]
```

The closest contiguous usable run is used.

The path is not allowed to jump across missing or guarded frames.

## Strict trajectory evidence used in the first follow-up

```text
local window                      30 base-30fps frames
minimum usable path               5 frames
maximum contact gap               2 base-30fps frames
recurrence buffer                15 source frames each side
largest-step ratio               <= 4.0
incoming threshold               +0.05 body heights
outgoing threshold               -0.05 body heights
```

The first outgoing-first search produced:

```text
first accepted contact retained       21/239
first accepted contact skipped       218/239
some contact selected                212/239
median selected rank                   3
maximum selected rank                 24
no outgoing-positive contact          27
```

At ±10 visible-start scoring:

```text
fixed                                 16
damaged                               34
unchanged correct                     18
unchanged wrong                       44
pre-contact unavailable              100
no credible accepted contact          27
```

## Relaxed trajectory evidence

The later trajectory evidence changes only two main eligibility settings:

```text
recurrence buffer                 3 source frames each side
largest-step ratio                <= 8.0
```

The other settings remain:

```text
local window                      30 base-30fps frames
minimum usable path               5 frames
maximum contact gap               2 base-30fps frames
incoming threshold               +0.05 body heights
outgoing threshold               -0.05 body heights
```

### Recurrence guard reconstruction

Production code 3 contains more than the halo itself.

The experimental reconstruction:

1. treats `FABRICATED` and `SUSPECT_FLAT` as recurrence core;
2. collects exact shuttle positions seen at core frames;
3. marks every repeated occurrence of those positions as `on_attractor`;
4. adds the chosen buffer around each contiguous core run;
5. marks `(buffer | on_attractor) & ~core` as degraded;
6. restores original core codes;
7. restores stored `(0, 0)` shuttle frames to `NO_FLAG`, matching production behaviour.

Reconstructing with the original 15-frame buffer reproduces production codes exactly on all three fixtures.

Using a 3-frame buffer changes 37,139 guard frames relative to the wider buffer:

| Fixture | Changed frames |
| --- | ---: |
| `sset_01` | 13,549 |
| `sset_15` | 15,161 |
| `sset_21` | 8,429 |

Across all three fixtures, 53,471 of 55,937 code-3 frames are buffer-only rather than recurrence core.

Inside the saved rally spans, 12,207 of 12,879 code-3 frames are buffer-only.

### Why the largest-step limit moved from 4 to 8

One reviewed contiguous post-contact sample contains:

```text
usable frames                      25
median non-zero step               0.084648 body heights
largest step                       0.577997 body heights
largest-step ratio                 6.828283
```

It failed the 4.0 limit despite containing no missing-frame jump.

The 8.0 value was fixed for the experiment rather than swept against GT.

## Frozen relaxed contact evidence

The write pass saved **3,200 accepted-contact rows**.

### Pre-contact path status

| Status | Contacts |
| --- | ---: |
| Eligible | 2,329 |
| Largest-step ratio too large | 321 |
| No usable run | 237 |
| Contact gap too large | 172 |
| Measurement unavailable | 74 |
| Too few frames | 56 |
| Contact context unavailable | 11 |

Pre-contact verdicts:

```text
incoming        1,963
not incoming      366
unavailable       871
```

### Post-contact path status

| Status | Contacts |
| --- | ---: |
| Eligible | 2,164 |
| Largest-step ratio too large | 526 |
| No usable run | 220 |
| Contact gap too large | 167 |
| Too few frames | 61 |
| Measurement unavailable | 51 |
| Contact context unavailable | 11 |

Credible outgoing is true for 1,568 accepted contacts.

## Relaxed outgoing-first search

Frozen categories:

```text
first visible post-serve contact      68
visible serve                         23
pre-contact unavailable              143
no credible outgoing contact           5
```

At ±10 visible-start scoring:

```text
final visible-start correct            43
fixed                                  26
damaged                                13
unchanged correct                      17
unchanged wrong                        35
pre-contact unavailable              143
no credible contact                     5
```

### Server re-score

Direct server answers:

```text
coverage                               91/239
correct                                60/91
```

With PR #82 fallback:

```text
correct                               170/239
changed vs PR #82                      33
fixes                                  20
damages                                13
```

## Derived standalone rank-1 default

Among the 143 pre-contact-unavailable selected contacts, path status is:

```text
no usable run                         90
largest-step ratio too large          25
measurement unavailable               13
too few frames                         11
contact gap too large                   4
```

Among the 90 `no usable run` rows, selected rank is:

```text
rank 1                                 69
rank 2                                 15
rank 3                                  3
rank 6                                  1
rank 7                                  1
rank 10                                 1
```

The rank-1 default adds those 69 rows to direct coverage.

Derived standalone direct coverage becomes:

```text
original measured serve/return answers        91
rank-1 outgoing default serve answers         69
-----------------------------------------------
total direct answers                          160
correct server sides                          120
```

Visible-serve claims:

```text
claims                                          92
GT contact 1 at ±10                             66
correct server side                             75
both contact 1 and server correct               59
```

Apparent-return claims:

```text
claims                                          68
GT contact 2 at ±10                             34
correct server side                             45
both contact 2 and server correct               33
```

## Three-frame minimum-path sensitivity

The stored measurements are sufficient to re-evaluate paths with `minimum usable path = 3` because 3- and 4-frame runs retain their measured direction, gap, and jump ratio in the frozen evidence.

Result:

```text
direct server answers                   96
direct correct server answers           60
final correct with PR #82 fallback     166/239
changed vs PR #82                       37
fixes                                    20
damages                                  17
```

The extra five direct answers add no net correct direct server classifications.

## Incoming-anchor predecessor search

A separate frozen search chooses the earliest contact with measured incoming motion and inspects the immediately preceding accepted contact.

Predecessor admission:

- ordinary accepted-contact gap ≤60 base-30fps frames; or
- measured high-shot state with the fixed endpoint buffer described below.

Result categories:

```text
visible serve                           44
first visible post-serve contact        33
predecessor unavailable                157
no incoming anchor with unavailable      5
```

At ±10 visible-start scoring:

```text
final correct                            26
fixed                                    23
damaged                                  24
unchanged correct                         3
unchanged wrong                          27
predecessor unavailable                 157
no incoming anchor                        5
```

Ordinary predecessor timing admits 196 predecessors.

Thirty-nine have measured not-incoming motion.

Only **3/39** are GT contact 1 at ±10.

## High-shot long-gap rule

The frozen production high-shot state uses a 75-base-30fps demotion bound and two-sided re-entry checks.

For a predecessor beyond the ordinary 60-frame cap, the fixed exception admits it when:

```text
earlier contact is <= 12 base-30fps frames from state start
AND
later contact is <= 12 base-30fps frames from state end
```

Across the full fixed population:

- 146 consecutive accepted-contact pairs bracket a measured high-shot state;
- 42 of those gaps exceed the ordinary 60-frame predecessor cap.

Descriptive long-gap admissions by endpoint buffer:

| Inclusive endpoint buffer | Long-gap pairs admitted |
| ---: | ---: |
| 6 | 0 |
| 9 | 5 |
| 10 | 6 |
| 12 | 9 |
| 15 | 18 |
| 30 | 21 |

The 12-frame value was fixed from the existing impulse half-window rather than a GT sweep.

The incoming-anchor search actually uses the high-shot exception in five rallies.

All five predecessors are GT contact 1 at ±10.

All five come from `sset_21`, video 21, set 1.

## Final additive high-shot correction in the original package

The original package keeps PR #82 by default and changes the answer only when the measured high-shot predecessor state supports a different visible serve.

Actions:

```text
NO-OP                  237
CORRECT                   2
CONFLICT                  0
```

Result:

```text
visible-start correct    125 → 127
server correct           163 → 164
```

The two visible-start changes are both fixes.

Only one changes the server side, and that change is also a fix.

## Serve-setup wrist evidence

The broad setup gate reuses:

```text
existing serve-start lookback
wrist proximity threshold        1.4 body heights
stillness gate                    off
```

Broad gate result:

```text
interventions                    138
visible-start fixes               22
visible-start damages             63
changed but still wrong           53
net fixes                        -41
server changes                    59
server fixes                      20
server damages                    39
```

A stricter same-player continuation state fires twice:

```text
one visible-start fix
one visible-start damage
zero server changes
```

## Other rejected combinations recorded in the source package

Relaxed incoming verdict at the original first accepted frame:

```text
9 server flips
5 fixes
4 damages
```

Ordinary measured predecessor pair with player difference:

```text
7 server contradictions with PR #82
1 fix
6 damages
```

Later incoming anchor with no admitted predecessor:

```text
6 visible-start changes
4 fixes
1 damage
1 still wrong
```

Rank-1 drop using later trajectory evidence, alternation, and server agreement:

```text
24 visible-start changes
7 fixes
9 damages
8 still wrong
```

## Current apparent-return traceback inputs

For the 68 apparent-return anchors produced by the relaxed outgoing search:

```text
no immediate predecessor                         14
has immediate predecessor                        54
predecessor credible outgoing true                0
```

Predecessor pre-motion verdicts among those 54:

```text
incoming                                         19
not incoming                                      6
unavailable                                      29
```

Only six combine an ordinary ≤60-base-30 gap with a measured not-incoming predecessor.

Only one of those six predecessors matches GT contact 1 at ±10.

One pair has a recorded measured high-shot state.

Zero satisfy the fixed ±12 high-shot bridge.

This shows that predecessor timing alone is not enough to recover the serve. A later proposal to use long-range physical shuttle continuity was reconsidered because the available feature is a monocular 2D projection of 3D shuttle motion. The current conclusion is to validate server side separately and avoid claiming full 3D continuity from this scalar distance signal.

## What `no_usable_run` hides

The usable local mask requires all relevant frame-level conditions to hold, including:

- usable/non-zero shuttle coordinates;
- positive track/visibility state;
- court/scene presence;
- finite player-relative distance;
- positive finite player body height;
- clean recurrence guard;
- same predicted rally span;
- same scene.

The frozen contact table stores only the collapsed `no_usable_run` status.

It does not retain a per-frame failure reason.

A root-cause decomposition therefore needs the original frame-level inputs.

## Reproducibility files in this packet

`supporting/recompute_metrics.py` regenerates:

- `current_metrics.json`;
- `current_server_reanalysis.csv.gz`;
- `minimum_path_3_sensitivity.csv.gz`;
- `no_usable_pre_run_cases.csv.gz`;
- `apparent_return_cases.csv.gz`.

It uses only the copied frozen source CSVs under `supporting/`.

The untouched original package is preserved under `originals/`.

# Current additions after reconstructing the original objective

## A. Simplified complete server-ID cascade

The current development rule can be written without the earlier 160-rally intermediate construct.

For each of the 239 one-to-one rallies:

```text
if sequential_category == visible_serve:
    server = sequential_selected_player
elif sequential_category == first_visible_post_serve_contact:
    server = other(sequential_selected_player)
else:
    if rank1_pre_verdict == incoming:
        server = other(rank1_player)
    else:
        server = rank1_player
```

This uses the frozen relaxed contact evidence.

Branch counts and scores:

| Branch | Count | Correct |
| --- | ---: | ---: |
| sequential incoming | 68 | 45 |
| sequential not incoming | 23 | 15 |
| fallback rank-1 incoming | 3 | 3 |
| fallback rank-1 default side | 145 | 108 |
| **Total** | **239** | **171** |

The corresponding frozen output is `supporting/server_id_cascade_171.csv.gz`.

`supporting/recompute_server_id_cascade.py` rebuilds it from the copied original frozen evidence.

No GT field is used to choose a branch or prediction. GT is present only in the scored output columns.

Compared with PR #82, the cascade changes 34 server answers: 21 fixes and 13 damages.

## B. Why 160/239 remains in the packet

The 160-rally number came from an earlier diagnostic decomposition:

```text
91 measured selected-contact decisions
+69 rank-1 outgoing-positive / no-usable-pre-run defaults
=160 direct decisions
```

This was useful for understanding coverage and timing claims.

It is not required to implement the preferred server rule.

The preferred rule keeps PR #82 whenever the strong selected-contact inference is unavailable. This scores 170/239.

A rank-1 fallback sensitivity scores 171/239, but it loses one correct temporal-slot attribution and does not improve joint temporal-and-server correctness.

## C. Arc-aware rescue prototype

The original PR #82 robust trend rule uses one median-of-pair-slopes trend over the whole observed path.

The proposed rescue is one-way and additive.

Current `incoming` calls are never changed.

For a current `not incoming` call, the demonstration requires:

```text
observed samples                         >= 6
quadratic RMSE improvement vs linear    >= 30%
quadratic vertex position               0.20 .. 0.80
observed samples left of vertex         >= 3
observed samples right of vertex        >= 3
early robust slope                      > 0   # receding
a late robust slope                      < 0   # approaching
late fitted decrease                    >= 0.05 BH
```

The quadratic is not used as the direction classifier.

It only finds the candidate turning point.

The two limbs are then fitted with robust median-of-pair-slopes / Theil-Sen-style slopes.

On the eight digitised error paths supplied in the conversation, the prototype rescues two missed first returns:

- `sset_15 set2 rally 6`;
- `sset_01 set3 rally 13`.

It leaves the four existing false-return calls unchanged.

This is not yet a full 19-path result.

The other 11 labelled usable paths must be rerun from the original samples to determine whether the rescue introduces any new damage.

The demonstration source is `supporting/arc_rescue_demo.py`.

The supplied and annotated figures are under `figures/`.
