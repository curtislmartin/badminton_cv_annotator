# Small curved-path rescue for the incoming-motion rule

## Why this exists

The current incoming classifier reduces the whole observed player-relative distance path to one robust linear trend.

That is sensible for a monotonic path.

It can be misleading when the observed 2D path has a clear turn.

The proposed change is deliberately small:

> Keep the existing 0.05-BH rule. Only give a current `not incoming` call a second chance when the observed path itself has a well-supported interior arc.

This does not attempt to recover 3D shuttle height.

It only stops a single straight-line slope from describing a visibly curved 2D trace.

## Frozen prototype rule

Run the current robust whole-path trend first.

If the current verdict is `incoming`, keep it.

If the current verdict is `not incoming`:

1. fit a quadratic to distance-to-contact-player against normalised path position;
2. require at least 6 observed samples;
3. require the quadratic RMSE to improve on the linear RMSE by at least 30%;
4. require the quadratic vertex to lie between 20% and 80% of the observed path;
5. require at least 3 observed samples on each side of the vertex;
6. use the quadratic only to choose the split point;
7. fit robust early- and late-limb slopes using the median-of-pair-slopes / Theil-Sen idea;
8. require the early limb to be receding and the late limb to be approaching;
9. rescue the verdict to `incoming` only when the fitted late limb closes by at least 0.05 BH over the observed late limb.

In shorthand:

```text
existing incoming
    → keep incoming

existing not incoming
    + supported interior arc
    + early limb receding
    + late limb approaching by >= 0.05 BH
    → rescue to incoming

otherwise
    → keep not incoming
```

## Why it is one-way

The supplied eight-error figure contains four false return calls and four missed first returns.

Some false return calls look strongly incoming in 2D even though GT says they are serves.

The scalar 2D distance does not contain enough information to reverse those calls safely.

So this first refinement does **not** try to suppress existing incoming calls.

It only tries to recover missed returns where the whole-path linear summary hides a clear late approach.

That makes it an additive recall rescue rather than a replacement classifier.

## What the demonstration does

The supplied figure contains all eight mistakes made by the original 0.05-BH trend rule among 19 labelled usable unique-truth paths.

The prototype was applied to points digitised from that figure.

It rescues two missed first returns:

| Path | GT | Old verdict | New verdict | Effect |
| --- | --- | --- | --- | --- |
| `sset_15 set2 rally 6` | first return | not incoming | incoming | **fix** |
| `sset_01 set3 rally 13` | first return | not incoming | incoming | **fix** |

The other six errors remain errors.

That is intentional. They do not present a comparably safe shape-based rescue under this limited signal.

## Diagram

`figures/arc_rescue_annotated.png` overlays the prototype on the supplied error figure.

For supported curved paths it shows:

- the detected turning point;
- robust early-limb fit;
- robust late-limb fit;
- old verdict;
- new verdict;
- whether the change fixes the known sample.

The untouched supplied figure is preserved as `figures/trend_rule_errors.original.png`.

## What has not been proved

The demonstration uses only the eight error paths shown in the supplied image.

The other 11 labelled usable paths are not in that figure.

Therefore we cannot yet say:

> the original rule improves from 11/19 to 13/19.

That claim requires the exact frozen rule to be rerun on the original per-frame path samples for **all 19** labelled usable paths.

The rule should then be left unchanged and tested on unseen data.

## Why this is probably the right limit for this feature

A path that looks monotonic and strongly incoming in 2D can still be a GT serve because the real shuttle moves in 3D.

A GT return can also project as flat or receding in 2D.

No decomposition of the same scalar distance trace can recover information that is not present in the projection.

The principled boundary is therefore:

- use the existing robust trend when the observed path is adequately monotonic;
- use the arc decomposition only when the observed 2D path itself contains a well-supported turn;
- otherwise accept that the feature is ambiguous.

Further large gains would need a new observation rather than more rules over the same scalar path.

## Code

`supporting/arc_rescue_demo.py` reproduces the demonstration from digitised points in the supplied image.

It is demonstration code, not production code.

For a real evaluation, reuse the same frozen rule on the original path samples rather than re-digitising the plot.
