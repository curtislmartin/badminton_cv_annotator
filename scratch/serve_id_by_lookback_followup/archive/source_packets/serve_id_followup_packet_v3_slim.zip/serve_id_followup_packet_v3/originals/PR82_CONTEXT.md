# PR #82 context

Source: https://github.com/ahalp90/badminton_cv_annotator/pull/82

Title: `Investigation/serve start trajectory`

The pull request describes its main question as whether shuttle motion before the earliest accepted contact can improve the guess about who served.

Its reported server-side comparison is:

```text
released alternating-player fit     124/239 correct
PR #82 direct motion rule            163/239 correct
```

The pull request explicitly describes the direct result as standalone rather than depending on the old rhythm fit.

The user clarified the intended interpretation for this follow-up:

> Start from the already claimed rally sequence. If an apparent opening contact has incoming shuttle motion and there is no credible preceding hit, infer that the claimed opener is actually the first return, which implies an unseen serve from the other side. The follow-up was meant to test whether this physical reasoning could be extended into a global replacement for the existing server-ID rules.
