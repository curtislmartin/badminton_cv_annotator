# Serve identification follow-up: current conclusion

## Global summary

The original question was:

> Can the PR #82 shuttle-motion idea replace the older server-ID heuristic across whole rallies?

The answer is now clearer than the original follow-up reports made it seem.

**Yes, there is a complete GT-free server-ID rule worth validating.** On the 239-rally development set the preferred rule gets **170/239 server sides correct**.

That rule does not need ground truth at runtime. Ground truth is used only after the prediction is frozen, to score it.

The investigation also shows a separate limit. **Server side is easier than exact serve timing.** PR #82 gets 163/239 server sides right but only 125/239 visible-start interpretations right. Many of the extra side-correct cases start the rally at the wrong time but happen to land on the true server's side.

The previous follow-up spent too much effort treating exact opener-frame recovery as the main score. That made the overall result look worse than it is for server identification.

There is one small new trajectory refinement that is still worth testing. The current incoming-motion rule reduces each path to one robust linear trend. A clearly curved path can therefore be misread. A narrow **arc-aware rescue** can keep the existing rule and revisit only current `not incoming` calls with a well-supported interior turn. On the eight supplied PR #82 mistakes, the prototype rescues **2 missed first returns** and does not overturn any existing positive incoming call.

That two-case rescue is only a demonstration. The supplied figure contains the eight errors, not the other 11 labelled usable paths. The exact rule must be rerun on the original samples before we can claim a net improvement.

## The server-ID rule to validate

Start from the existing predicted rally span and its accepted contacts.

1. Find the earliest accepted contact with credible outgoing shuttle motion.
2. If the shuttle motion immediately before that contact is measurable:
   - `incoming` → the contact is return-like → **other side served**;
   - `not incoming` → the contact is serve-like → **that contact's side served**.
3. If that strong test cannot assign a server, **keep the PR #82 answer**.

On the development set:

| Rule | Correct server sides |
| --- | ---: |
| Older released alternating fit | 124/239 |
| Player at earliest accepted contact | 152/239 |
| PR #82 | 163/239 |
| **Preferred outgoing-search + PR #82 fallback** | **170/239** |
| Rank-1 fallback sensitivity | 171/239 |

The 171 sensitivity gains one server-side answer but loses one correct temporal-slot attribution. Both rules have 117/239 rallies where the temporal interpretation and server side are jointly correct. Prefer the simpler 170 rule.

## Numbers that must not be mixed together

| Number | Meaning |
| --- | --- |
| **125/239** | PR #82 gets the visible-start interpretation right: 115 visible serves + 10 first returns. |
| **163/239** | PR #82 gets the server side right. |
| **170/239** | **Preferred server rule:** outgoing-selected inference, with PR #82 as fallback. |
| **171/239** | Rank-1 fallback sensitivity; one more side-correct answer, but one fewer correct temporal slot. |
| **160/239** | Earlier diagnostic count of direct decisions after explicitly promoting 69 rank-1/no-run cases. **Coverage, not correctness.** |
| **120/160** | Correct server sides within that 160-rally diagnostic population. |

The 160 figure is useful for understanding the evidence. It is not needed as a stage in the preferred rule.

## What the investigation did and did not solve

It did find useful local evidence for server side.

It did not find a broad, reliable way to recover the exact serve frame from accepted-contact order and 2D shuttle distance alone.

That is not surprising. The distance signal is a monocular 2D projection of 3D shuttle motion. A high or arcing shot can move substantially in depth while its projected player-relative distance stays flat or even changes direction.

The right response is not to invent a 3D trajectory model from this scalar signal.

The small arc-aware rescue does something more modest: when the observed 2D distance path itself has a clear turn, it stops pretending that one straight-line slope describes the whole path.

## What to do next

There are two immediate checks.

**First, validate the server-ID rule.** Freeze the preferred 170/239 rule exactly and run it on unseen rallies. This is the main unanswered product question.

**Second, validate the arc-aware rescue on the original path samples.** Run the frozen rescue rule on all 19 labelled usable PR #82 paths, not just the eight mistakes shown in the figure. If it gives a net gain without creating new false return calls, then test the same local measurement change on unseen data.

Do not make “physical trajectory continuity across long gaps” the next main experiment. The previous series already explored local predecessor timing, high-shot gaps, outgoing/incoming evidence, alternation, and pose setup. More importantly, monocular 2D distance is not a trustworthy basis for reconstructing full 3D shuttle continuity.

If exact serve timing needs a large further improvement, it probably needs a genuinely new observation such as local racket or hitting-arm evidence.

## Read order

1. `README.md` — global conclusion and recommendation.
2. `01_NARRATIVE.md` — what happened, in order.
3. `02_CURRENT_EVIDENCE.md` — the current numbers and what they mean.
4. `03_ARC_AWARE_RESCUE.md` — the small curved-path refinement.
5. `04_NEXT_STEPS.md` — the two tests that are actually worth running next.
6. `05_TECHNICAL_REFERENCE.md` — thresholds, counts, failure states, and method boundaries.
7. `06_TRACEABILITY.md` — old opaque names mapped to plain names and source files.
8. `NEXT_WINDOW_PROMPT.md` — short prompt for a fresh analysis window.

The untouched original reports and source package are preserved under `originals/`.
