# What is worth doing next

## 1. Validate the server-ID rule on unseen rallies

This is the main next test.

Freeze the preferred rule exactly:

```text
find earliest outgoing-positive accepted contact

if its pre-motion is measurable:
    incoming     → other side served
    not incoming → selected-contact side served
else:
    keep the PR #82 server answer
```

Keep the current relaxed local trajectory settings:

```text
recurrence buffer              3 source frames around recurrence core
largest-step ratio             <= 8.0
minimum usable path            5 frames
local window                   30 base-30fps frames
maximum gap to contact         2 base-30fps frames
incoming threshold             +0.05 BH fitted decrease
outgoing threshold             -0.05 BH fitted decrease
```

Do not tune those values on the holdout.

The development reference is **170/239 correct server sides**.

A 171/239 rank-1 fallback sensitivity exists, but it does not improve joint temporal-and-server correctness and is not the preferred rule.

The holdout should report the same branch counts and branch-wise accuracy so we can see whether the gain generalises or comes from one particular fallback group.

## 2. Rerun the arc-aware rescue on the original 19 paths

Before changing production behaviour, obtain the original per-frame path samples used by the PR #82 motion audit.

Run the frozen rule in `03_ARC_AWARE_RESCUE.md` on all 19 labelled usable unique-truth paths.

Do not tune the thresholds after seeing the 19-path result.

Report:

- old verdict;
- arc-supported yes/no;
- turning point;
- early robust slope;
- late robust slope;
- late fitted decrease;
- new verdict;
- whether the verdict changed;
- GT serve/first-return label, joined only after the new verdict is frozen.

The immediate question is simple:

> Do the two demonstrated rescues survive exact data, and do any of the 11 currently-correct paths get damaged?

If the answer is net positive, test the same rule on unseen data.

## 3. Keep server side and timing as separate outputs

The global server-ID rule should not be forced to invent a serve frame.

When the strong selected-contact evidence is available, it can record whether the selected contact looked serve-like or return-like.

When the rule falls back to rank 1 for server side, treat that primarily as a side decision unless independent timing evidence is strong enough to support a frame claim.

This avoids turning “right side for the wrong temporal reason” into a false claim of exact serve timing.

## 4. Do not make long-range 2D trajectory continuity the main next experiment

The earlier experiment series already tested:

- outgoing validation;
- incoming classification;
- immediate predecessors;
- ordinary time gaps;
- the measured high-shot ±12 long-gap exception;
- player alternation;
- serve-setup wrist evidence;
- scene/rally boundaries.

A new long-range continuity rule would also face a deeper problem.

The current path feature is a monocular 2D projection of 3D shuttle motion. Without reliable depth or height, an arcing shuttle can have misleading projected distance.

So full physical traceback would risk creating a precise story from evidence that cannot support it.

## 5. If exact serve timing still matters, add a new observation

The most useful genuinely new evidence would probably be local contact verification in RGB.

Examples include:

- racket movement;
- hitting-arm movement;
- a local pose/action cue around the accepted impulse.

That asks a more direct question:

> Did a physical stroke actually happen at this accepted contact?

The frozen 288p source videos contain no audio stream, so contact-sound evidence is not available on this fixture set.
