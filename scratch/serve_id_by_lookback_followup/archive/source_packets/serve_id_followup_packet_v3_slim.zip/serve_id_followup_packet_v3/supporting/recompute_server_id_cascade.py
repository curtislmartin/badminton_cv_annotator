#!/usr/bin/env python3
"""Rebuild the 171/239 rank-1 fallback sensitivity from frozen follow-up evidence.

Prediction branches use only frozen contact/player/trajectory fields. Ground truth
is read only after the prediction is fixed, to append scoring columns.
"""
from __future__ import annotations

import csv
import gzip
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONTACT_EVIDENCE = HERE / "relaxed_contact_evidence.original.csv.gz"
SEARCH_RESULTS = HERE / "relaxed_search_results.original.csv.gz"
SCORED_BASELINE = HERE / "additive_correction_results.original.csv.gz"
OUTPUT = HERE / "server_id_cascade_171.csv.gz"

KEY = ("fixture", "video_id", "set_id", "rally")


def read_rows(path: Path) -> list[dict[str, str]]:
    with gzip.open(path, "rt", newline="") as handle:
        return list(csv.DictReader(handle))


def key(row: dict[str, str]) -> tuple[str, str, str, str]:
    return tuple(row[name] for name in KEY)  # type: ignore[return-value]


def other(player: str) -> str:
    if player == "Top":
        return "Bot"
    if player == "Bot":
        return "Top"
    raise ValueError(f"unexpected player {player!r}")


def main() -> None:
    contacts = read_rows(CONTACT_EVIDENCE)
    searches = read_rows(SEARCH_RESULTS)
    scored = read_rows(SCORED_BASELINE)

    rank1: dict[tuple[str, str, str, str], dict[str, str]] = {}
    for row in contacts:
        if row["accepted_rank"] == "1":
            k = key(row)
            if k in rank1:
                raise ValueError(f"duplicate rank-1 row for {k}")
            rank1[k] = row

    score_by_key = {key(row): row for row in scored}
    output: list[dict[str, str]] = []

    for search in searches:
        k = key(search)
        first = rank1[k]

        category = search["sequential_category"]
        if category == "first_visible_post_serve_contact":
            prediction = other(search["sequential_selected_player"])
            branch = "selected_outgoing_contact__incoming__other_side"
        elif category == "visible_serve":
            prediction = search["sequential_selected_player"]
            branch = "selected_outgoing_contact__not_incoming__selected_side"
        else:
            if first["pre_verdict"] == "incoming":
                prediction = other(first["player"])
                branch = "fallback_rank1__incoming__other_side"
            else:
                prediction = first["player"]
                branch = "fallback_rank1__otherwise__rank1_side"

        # Prediction is now frozen. GT is read only for scoring below.
        gt = score_by_key[k]["gt_server"]
        pr82 = score_by_key[k]["baseline_server"]
        output.append(
            {
                **{name: search[name] for name in KEY},
                "prediction_branch": branch,
                "predicted_server": prediction,
                "selected_outgoing_category": category,
                "selected_outgoing_frame": search["sequential_selected_frame"],
                "selected_outgoing_rank": search["sequential_selected_rank"],
                "selected_outgoing_player": search["sequential_selected_player"],
                "selected_outgoing_pre_verdict": search["sequential_selected_pre_verdict"],
                "rank1_player": first["player"],
                "rank1_pre_verdict": first["pre_verdict"],
                "rank1_pre_path_status": first["pre_path_status"],
                "rank1_credible_outgoing": first["credible_outgoing"],
                "pr82_server": pr82,
                "gt_server": gt,
                "predicted_server_correct": str(prediction == gt),
                "pr82_server_correct": str(pr82 == gt),
                "changed_vs_pr82": str(prediction != pr82),
            }
        )

    fields = list(output[0])
    with gzip.open(OUTPUT, "wt", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(output)

    correct = sum(row["predicted_server_correct"] == "True" for row in output)
    baseline = sum(row["pr82_server_correct"] == "True" for row in output)
    print(f"PR #82: {baseline}/{len(output)}")
    print(f"Rank-1 fallback sensitivity: {correct}/{len(output)}")

    counts: dict[str, list[int]] = {}
    for row in output:
        branch = row["prediction_branch"]
        if branch not in counts:
            counts[branch] = [0, 0]
        counts[branch][0] += 1
        counts[branch][1] += row["predicted_server_correct"] == "True"

    for branch, (count, branch_correct) in counts.items():
        print(f"{branch}: {branch_correct}/{count}")

    changed = [row for row in output if row["changed_vs_pr82"] == "True"]
    fixes = sum(
        row["predicted_server_correct"] == "True" and row["pr82_server_correct"] == "False"
        for row in changed
    )
    damages = sum(
        row["predicted_server_correct"] == "False" and row["pr82_server_correct"] == "True"
        for row in changed
    )
    print(f"Changes vs PR #82: {len(changed)}; fixes {fixes}; damages {damages}")
    print(OUTPUT)


if __name__ == "__main__":
    main()
