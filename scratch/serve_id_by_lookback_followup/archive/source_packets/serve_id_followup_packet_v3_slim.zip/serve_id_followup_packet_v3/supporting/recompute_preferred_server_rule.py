#!/usr/bin/env python3
"""Rebuild the preferred GT-free server-ID rule from frozen follow-up evidence.

The rule uses the relaxed outgoing-selected serve/return inference when that
search can classify a contact. Otherwise it keeps the frozen PR #82 server
answer. Ground truth is read only after the prediction is fixed, for scoring.
"""
from __future__ import annotations

import csv
import gzip
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEARCH_RESULTS = HERE / "relaxed_search_results.original.csv.gz"
SCORED_BASELINE = HERE / "additive_correction_results.original.csv.gz"
OUTPUT = HERE / "server_id_preferred_170.csv.gz"
KEY = ("fixture", "video_id", "set_id", "rally")


def read_rows(path: Path) -> list[dict[str, str]]:
    with gzip.open(path, "rt", newline="") as handle:
        return list(csv.DictReader(handle))


def key(row: dict[str, str]) -> tuple[str, str, str, str]:
    return tuple(row[name] for name in KEY)  # type: ignore[return-value]


def other(player: str) -> str:
    return {"Top": "Bot", "Bot": "Top"}[player]


def main() -> None:
    searches = read_rows(SEARCH_RESULTS)
    scored = {key(row): row for row in read_rows(SCORED_BASELINE)}
    output: list[dict[str, str]] = []

    for search in searches:
        k = key(search)
        baseline = scored[k]
        category = search["sequential_category"]

        if category == "first_visible_post_serve_contact":
            prediction = other(search["sequential_selected_player"])
            temporal_claim = "return"
            temporal_gt_label = search["tolerance_10_sequential_selected_label"]
            claimed_frame = search["sequential_selected_frame"]
            branch = "selected_outgoing_contact__incoming__other_side"
        elif category == "visible_serve":
            prediction = search["sequential_selected_player"]
            temporal_claim = "serve"
            temporal_gt_label = search["tolerance_10_sequential_selected_label"]
            claimed_frame = search["sequential_selected_frame"]
            branch = "selected_outgoing_contact__not_incoming__selected_side"
        else:
            prediction = baseline["baseline_server"]
            temporal_claim = (
                "serve" if baseline["baseline_category"] == "visible_serve" else "return"
            )
            temporal_gt_label = baseline["baseline_gt_label"]
            claimed_frame = baseline["baseline_frame"]
            branch = "pr82_fallback"

        # Prediction is now frozen. GT is read only for scoring below.
        gt_server = baseline["gt_server"]
        temporal_correct = (
            (temporal_claim == "serve" and temporal_gt_label == "contact_1")
            or (temporal_claim == "return" and temporal_gt_label == "contact_2")
        )
        server_correct = prediction == gt_server

        output.append(
            {
                **{name: search[name] for name in KEY},
                "prediction_branch": branch,
                "predicted_server": prediction,
                "claimed_frame": claimed_frame,
                "temporal_claim": temporal_claim,
                "temporal_gt_label_at_10": temporal_gt_label,
                "server_correct": str(server_correct),
                "temporal_slot_correct": str(temporal_correct),
                "joint_temporal_and_server_correct": str(server_correct and temporal_correct),
                "gt_server": gt_server,
            }
        )

    with gzip.open(OUTPUT, "wt", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(output[0]))
        writer.writeheader()
        writer.writerows(output)

    n = len(output)
    server = sum(row["server_correct"] == "True" for row in output)
    temporal = sum(row["temporal_slot_correct"] == "True" for row in output)
    joint = sum(row["joint_temporal_and_server_correct"] == "True" for row in output)
    serve_frames = sum(
        row["temporal_claim"] == "serve" and row["temporal_gt_label_at_10"] == "contact_1"
        for row in output
    )
    print(f"Preferred server rule: {server}/{n} server sides correct")
    print(f"Temporal slot correct: {temporal}/{n}")
    print(f"Joint temporal + server correct: {joint}/{n}")
    print(f"Correct visible serve-frame claims: {serve_frames}")
    print(OUTPUT)


if __name__ == "__main__":
    main()
