# Arc-aware rescue prototype

This is deliberately additive. It does not retune or overturn an existing PR #82 incoming call.

## Rule

1. Run the existing 0.05-BH robust whole-path trend rule.
2. If it says **incoming**, keep that verdict.
3. If it says **not incoming**, fit distance-to-contact-player against normalised path position with a quadratic.
4. Treat the path as a supported arc only when:
   - at least 6 observed samples are available;
   - the quadratic reduces RMSE by at least 30% versus a straight line;
   - the vertex lies between 20% and 80% of the observed path;
   - at least 3 samples lie on each side of the vertex;
   - the robust early limb is receding (distance increasing); and
   - the robust late limb is approaching (distance decreasing).
5. Use the quadratic only to locate the split. Fit each limb with the same median-of-pair-slopes / Theil–Sen idea used by the current robust trend.
6. Rescue the verdict to **incoming** only if the fitted late limb closes by at least 0.05 BH over the observed late limb.

## What it does on the eight supplied mistakes

| Path | GT | Old verdict | Supported arc? | Late decrease | New verdict | Effect |
|---|---|---|---:|---:|---|---|
| `sset_15 set1 rally25` | serve | incoming | no | — | incoming | **still wrong** |
| `sset_01 set2 rally30` | serve | incoming | no | — | incoming | **still wrong** |
| `sset_01 set1 rally9` | serve | incoming | yes | 0.578 BH | incoming | **still wrong** |
| `sset_21 set1 rally40` | serve | incoming | yes | 1.632 BH | incoming | **still wrong** |
| `sset_01 set1 rally2` | return | not incoming | no | — | not incoming | **still wrong** |
| `sset_15 set1 rally3` | return | not incoming | no | — | not incoming | **still wrong** |
| `sset_15 set2 rally6` | return | not incoming | yes | 0.134 BH | incoming | **fix** |
| `sset_01 set3 rally13` | return | not incoming | yes | 0.114 BH | incoming | **fix** |

On this eight-error sample, the rule fixes **2/8** errors: `sset_15 set2 rally6` and `sset_01 set3 rally13`.

It intentionally leaves the four existing false-return calls alone. This version is a *recall rescue* for missed returns, not a new rule for suppressing current positives.

## Important validation limit

The figure contains only the eight mistakes. The other 11 usable unique-truth paths are not present in the supplied image, so this sample cannot tell us whether either of the two currently-correct GT serves that the base rule calls not-incoming would be incorrectly rescued.

The plotted points used here were digitised from the supplied figure. For a production decision, rerun this exact frozen rule on the original per-frame distance samples for all 19 usable unique-truth paths, then on a holdout.