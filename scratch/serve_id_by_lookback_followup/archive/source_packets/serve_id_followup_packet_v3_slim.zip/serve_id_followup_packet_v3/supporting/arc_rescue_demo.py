#!/usr/bin/env python3
"""Reproduce the limited arc-aware rescue demonstration.

This script uses points digitised from figures/trend_rule_errors.original.png.
It demonstrates the frozen rule on the eight plotted errors only. It is not a
substitute for rerunning the rule on the original per-frame path samples.
"""
from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "figures" / "trend_rule_errors.original.png"
OUTPUT = ROOT / "figures" / "arc_rescue_annotated.png"

# Pixel locations digitised from the supplied figure. A handful of points hidden
# by the original text boxes are left as None rather than invented.
POINTS = {
    "sset_15 set1 rally25": [(119.80,169.39),(279.50,177.15),(438.50,251.90),(595.82,362.32),(756.30,462.39)],
    "sset_01 set2 rally30": [(922.79,179.83),(1082.24,162.13),(1239.57,227.52),(1400.34,268.27),(1559.28,462.43)],
    "sset_01 set1 rally9": [(119.90,887.50),(177.72,861.43),(235.66,814.72),(293.61,708.70),(351.54,626.32),(409.43,611.43),(467.39,624.30),(525.33,670.12),(583.30,733.61),(641.10,820.50),(698.35,902.42),(756.34,963.28)],
    "sset_21 set1 rally40": [(922.79,891.17),(1048.79,671.46),(1177.10,611.50),(1304.86,694.69),(1430.93,804.74),(1559.22,963.22)],
    "sset_01 set1 rally2": [(120.0,1404.58),(225.9,None),(332.5,1348.0),(438.43,1260.43),(545.76,1225.90),(650.34,1201.72),(756.34,1112.28)],
    "sset_15 set1 rally3": [(922.8,None),(971.57,1385.43),(1022.89,1404.21),(1069.80,1403.33),(1118.45,1418.62),(1167.83,1460.34),(1216.61,1463.70),(1265.42,1420.65),(1313.60,1237.68),(1363.34,1209.94),(1412.34,1155.83),(1460.95,1149.51),(1510.43,1113.57),(1559.28,1235.66)],
    "sset_15 set2 rally6": [(119.8,None),(199.36,None),(279.50,1853.64),(358.51,1799.95),(438.38,1755.45),(517.50,1705.36),(597.84,1705.52),(678.74,1659.24),(756.29,1804.29)],
    "sset_01 set3 rally13": [(922.8,None),(949.68,1902.41),(975.70,1837.39),(1002.65,1781.58),(1028.70,1745.61),(1055.58,1715.35),(1081.66,1672.28),(1108.50,1643.90),(1134.61,1638.30),(1161.50,1619.85),(1187.66,1626.83),(1214.53,1619.24),(1240.62,1613.55),(1267.50,1618.50),(1294.39,1624.30),(1320.46,1626.32),(1347.39,1631.30),(1373.98,1643.60),(1400.34,1648.28),(1426.61,1636.84),(1453.75,1631.88),(1479.42,1645.35),(1506.28,1667.90),(1532.35,1704.58),(1559.29,1732.29)],
}

# Two labelled y-grid lines per subplot recover an affine pixel->BH mapping.
YMAP = {
    "sset_15 set1 rally25": ((124,1.2),(420,.4)),
    "sset_01 set2 rally30": ((143,1.8),(418,1.0)),
    "sset_01 set1 rally9": ((619,.9),(928,.4)),
    "sset_21 set1 rally40": ((648,2.0),(977,0.0)),
    "sset_01 set1 rally2": ((1169,.20),(1467,.12)),
    "sset_15 set1 rally3": ((1139,.475),(1473,.30)),
    "sset_15 set2 rally6": ((1629,.7),(1924,.3)),
    "sset_01 set3 rally13": ((1663,.7),(1937,.3)),
}

META = {
    "sset_15 set1 rally25": dict(gt="serve", current="incoming", x0=119.8, x1=756.3),
    "sset_01 set2 rally30": dict(gt="serve", current="incoming", x0=922.8, x1=1559.3),
    "sset_01 set1 rally9": dict(gt="serve", current="incoming", x0=119.8, x1=756.3),
    "sset_21 set1 rally40": dict(gt="serve", current="incoming", x0=922.8, x1=1559.3),
    "sset_01 set1 rally2": dict(gt="return", current="not incoming", x0=119.8, x1=756.3),
    "sset_15 set1 rally3": dict(gt="return", current="not incoming", x0=922.8, x1=1559.3),
    "sset_15 set2 rally6": dict(gt="return", current="not incoming", x0=119.8, x1=756.3),
    "sset_01 set3 rally13": dict(gt="return", current="not incoming", x0=922.8, x1=1559.3),
}


def pixel_to_bh(name: str, py: float) -> float:
    (p1,v1),(p2,v2) = YMAP[name]
    return v1 + (py-p1)*(v2-v1)/(p2-p1)


def bh_to_pixel(name: str, value: float) -> float:
    (p1,v1),(p2,v2) = YMAP[name]
    return p1 + (value-v1)*(p2-p1)/(v2-v1)


def robust_slope(x: np.ndarray, y: np.ndarray) -> float:
    slopes = []
    for i in range(len(x)):
        for j in range(i+1, len(x)):
            dx = x[j] - x[i]
            if dx != 0:
                slopes.append((y[j] - y[i]) / dx)
    if not slopes:
        return math.nan
    return float(np.median(slopes))


def analyse(name: str) -> dict[str, object]:
    points = POINTS[name]
    x_all = np.linspace(0.0, 1.0, len(points))
    y_all = np.array([np.nan if py is None else pixel_to_bh(name, py) for _,py in points])
    keep = np.isfinite(y_all)
    x = x_all[keep]
    y = y_all[keep]

    linear = np.polyfit(x, y, 1)
    quadratic = np.polyfit(x, y, 2)
    linear_rmse = float(np.sqrt(np.mean((y - np.polyval(linear, x))**2)))
    quadratic_rmse = float(np.sqrt(np.mean((y - np.polyval(quadratic, x))**2)))
    improvement = 0.0 if linear_rmse == 0 else 1.0 - quadratic_rmse / linear_rmse

    a,b,_ = quadratic
    vertex = float(-b/(2*a)) if a != 0 else math.nan
    left = x <= vertex
    right = x >= vertex
    early = robust_slope(x[left], y[left]) if left.sum() >= 2 else math.nan
    late = robust_slope(x[right], y[right]) if right.sum() >= 2 else math.nan
    late_decrease = (
        float(-late * (x[right].max() - x[right].min()))
        if right.sum() >= 2 and math.isfinite(late)
        else math.nan
    )

    arc = (
        len(x) >= 6
        and 0.20 <= vertex <= 0.80
        and left.sum() >= 3
        and right.sum() >= 3
        and improvement >= 0.30
        and math.isfinite(early) and math.isfinite(late)
        and early > 0
        and late < 0
    )

    old = META[name]["current"]
    rescue = old == "not incoming" and arc and late_decrease >= 0.05
    new = "incoming" if old == "incoming" or rescue else "not incoming"
    return dict(x=x, y=y, quadratic=quadratic, improvement=improvement, vertex=vertex,
                early=early, late=late, late_decrease=late_decrease, arc=arc,
                old=old, new=new, rescue=rescue)


def main() -> None:
    image = np.asarray(Image.open(SOURCE).convert("RGB"))
    results = {name: analyse(name) for name in POINTS}

    shift = 250
    fig = plt.figure(figsize=(16.03, 23.2), dpi=100)
    ax = fig.add_axes([0,0,1,1])
    ax.imshow(image, extent=[0, image.shape[1], image.shape[0]+shift, shift])
    ax.set_xlim(0, image.shape[1])
    ax.set_ylim(image.shape[0]+shift, 0)
    ax.axis("off")

    ax.text(45, 32, "Arc-aware rescue layered on the existing PR #82 trend rule",
            fontsize=18, fontweight="bold", va="top")
    ax.text(45, 78,
            "Keep existing incoming calls. Rescue only a current NOT-INCOMING call when: "
            "quadratic RMSE improves ≥30%; vertex is 20–80% through the path; ≥3 samples each side; "
            "early limb recedes; late limb approaches by ≥0.05 BH.\n"
            "The quadratic only locates the turn; robust limb slopes make the verdict.",
            fontsize=11.5, va="top", linespacing=1.35)

    for name, result in results.items():
        meta = META[name]
        x0, x1 = meta["x0"], meta["x1"]
        x = result["x"]
        y = result["y"]
        vertex = result["vertex"]

        if result["arc"]:
            left = x <= vertex
            right = x >= vertex
            for mask, slope, linestyle in ((left, result["early"], "--"), (right, result["late"], "-")):
                xm, ym = x[mask], y[mask]
                intercept = float(np.median(ym - slope*xm))
                xx = np.array([xm.min(), xm.max()])
                yy = intercept + slope*xx
                px = x0 + xx*(x1-x0)
                py = np.array([bh_to_pixel(name, value) for value in yy]) + shift
                ax.plot(px, py, linewidth=3.0, linestyle=linestyle)

            vpx = x0 + vertex*(x1-x0)
            qy = float(np.polyval(result["quadratic"], vertex))
            qyp = bh_to_pixel(name, qy) + shift
            ax.plot([vpx,vpx], [qyp-70,qyp+70], linestyle=":", linewidth=2)

        tx = 95 if x0 < 500 else 900
        first_y = next(py for _,py in POINTS[name] if py is not None)
        if first_y < 500:
            ty = 320
        elif first_y < 1000:
            ty = 820
        elif first_y < 1500:
            ty = 1320
        else:
            ty = 1820
        ty += shift

        if result["rescue"]:
            verdict = "FLIP → INCOMING / RETURN  ✓ fixes this sample"
        elif meta["current"] == "incoming":
            verdict = "KEEP → INCOMING / RETURN  ✗ still false on this GT serve"
        else:
            verdict = "KEEP → NOT INCOMING / SERVE  ✗ still misses this GT return"

        if result["arc"]:
            detail = (f"arc: yes | vertex {vertex:.2f} | RMSE gain {result['improvement']*100:.0f}%\n"
                      f"early slope {result['early']:+.2f} BH/path | late decrease {result['late_decrease']:.3f} BH")
        else:
            detail = "arc: no under the frozen support tests"

        ax.text(tx, ty, verdict + "\n" + detail, fontsize=9.4, va="top",
                bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.88))

    handles = [
        Line2D([0],[0], linestyle="--", linewidth=3, label="Robust early-limb fit"),
        Line2D([0],[0], linestyle="-", linewidth=3, label="Robust late-limb fit"),
        Line2D([0],[0], linestyle=":", linewidth=2, label="Quadratic turning point"),
    ]
    ax.legend(handles=handles, loc="upper right", bbox_to_anchor=(0.97,0.075), fontsize=10)
    fig.savefig(OUTPUT, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)

    print("Arc-aware demo results:")
    for name, result in results.items():
        print(f"{name}: {result['old']} -> {result['new']} | rescue={result['rescue']}")
    print(OUTPUT)


if __name__ == "__main__":
    main()
