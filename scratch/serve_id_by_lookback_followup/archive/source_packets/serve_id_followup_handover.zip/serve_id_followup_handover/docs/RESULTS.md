# Results and technical evidence

## 1. The two endpoints

The investigation uses two scores.

A **timing-slot** score asks whether a serve claim matches ground-truth contact 1, or whether a return claim matches contact 2.

A **server-side** score asks whether the predicted court side matches the ground-truth server side.

These scores are not interchangeable.
PR #82 has 67 rallies where its visible-start interpretation is wrong but its server side is right.

| Visible-start interpretation | Server side | Rallies |
| --- | --- | ---: |
| Correct | Correct | 96 |
| Wrong | Correct | 67 |
| Correct | Wrong | 29 |
| Wrong | Wrong | 47 |

The PR #82 timing score is 125/239.
Its server score is 163/239.

## 2. Evaluation populations

Three populations appear in PR #82 and the follow-up.

| Population | Rallies | Use |
| --- | ---: | --- |
| All ground-truth rallies | 292 | End-to-end context, including segmentation failure |
| Covered ground-truth rallies | 249 | Broader check, including merged spans |
| One predicted span to one ground-truth rally | 239 | Main timing and server comparison |

The rules in this bundle use the fixed 239-rally population.
That population was selected through a ground-truth crosswalk.
The prediction branches themselves do not read stroke labels or server labels.

The rules were composed after inspecting this development set.
They still need an unseen test.

## 3. PR #82 reference

[PR #82](https://github.com/ahalp90/badminton_cv_annotator/pull/82) asked whether shuttle motion before the earliest accepted contact could improve server identification.

| Method | Correct server sides |
| --- | ---: |
| Released alternating fit | 124/239 |
| Player at earliest accepted contact | 152/239 |
| Direct 0.05-body-height motion correction | 163/239 |
| Prepend inferred server and refit | 159/239 |

Only 24 of 239 rallies had a usable pre-contact path under the main recurrence check.
Nineteen usable paths had an unambiguous contact-1 or contact-2 timing label.
The fixed path classifier was correct on 11 of those 19 paths.

At the main ±10 base-30-fps tolerance, the earliest accepted contact had these labels:

| Label | Rallies |
| --- | ---: |
| Contact 1 | 119 |
| Contact 2 | 19 |
| Later contact | 4 |
| No matching stroke | 97 |

Later accepted contacts recovered a serve or first return in 85 of those 97 unmatched cases.
This motivated the follow-up timing investigation.

## 4. Strict outgoing-first search

The first follow-up search skipped accepted contacts until it found credible outgoing motion after a contact.
It then classified the path before that contact.

The fixed path rules were:

| Parameter | Value |
| --- | --- |
| Minimum path samples | 5 |
| Directional-change threshold | 0.05 apparent player body heights |
| Lookaround | 30 base-30-fps frames |
| Maximum local path gap | 2 base-30-fps frames |
| Maximum largest-step ratio | 4 |

The search selected a contact in 212 rallies.
It found no credible contact in 27.
The median selected accepted-contact rank was 3.

At ±10 it fixed 16 timing interpretations and damaged 34.
Another 100 rows had unknown pre-contact evidence.

| Transition | Rallies |
| --- | ---: |
| Fixed | 16 |
| Damaged | 34 |
| Stayed correct | 18 |
| Stayed wrong | 44 |
| Pre-contact evidence unknown | 100 |
| No credible contact | 27 |

The strict rule was too destructive to replace the opener interpretation.

## 5. Relaxed H3/R8 evidence

The next search kept the same basic motion interpretation and relaxed the evidence gate.

| Parameter | Value |
| --- | --- |
| Minimum path samples | 5 |
| Directional-change threshold | 0.05 body heights |
| Lookaround | 30 base-30-fps frames |
| Maximum local path gap | 2 frames |
| Maximum largest-step ratio | 8 |
| Ordinary predecessor gap | 60 base-30-fps frames |
| High-shot endpoint buffer | 12 base-30-fps frames |
| Excluded-frame halo | 3 source frames per side |

The frozen contact table contains 3,200 accepted contacts.
Its pre-contact verdicts are:

| Verdict | Contacts |
| --- | ---: |
| Incoming | 1,963 |
| Not incoming | 366 |
| Unavailable | 871 |

Its pre-contact path states are:

| State | Contacts |
| --- | ---: |
| Eligible | 2,329 |
| No usable run | 237 |
| Contact gap too large | 172 |
| Largest-step ratio too large | 321 |
| Measurement unavailable | 74 |
| Too few frames | 56 |
| Contact context unavailable | 11 |

The outgoing-selected rally results are:

| Category | Rallies |
| --- | ---: |
| Incoming before selected contact; return-like | 68 |
| Not incoming; serve-like | 23 |
| Selected contact but pre-contact evidence unavailable | 143 |
| No credible outgoing contact | 5 |

As a full timing replacement, this rule fixed 26 starts and damaged 13.
Only 43 of 239 final timing interpretations were correct.
The evidence was useful locally, but not as a general opener replacement.

## 6. Incoming-anchor predecessor search

A second search found an incoming contact and inspected its immediate predecessor.

| Predecessor admission | Rallies |
| --- | ---: |
| Ordinary gap rule | 196 |
| Measured high-shot bridge | 5 |
| No admitted predecessor | 38 |

Ordinary predecessor timing was weak.
Of 39 ordinary predecessors with measured not-incoming motion, only 3 matched contact 1 at ±10.

Requiring different players left 26 candidate changes.
They fixed 3 timing labels, damaged 10, and left 13 wrong.

The high-shot bridge was the one narrow positive state.
It appeared five times, all in `sset_21`, video 21, set 1.
Three cases agreed with the PR #82 frame.
Two cases changed the frame.
Both changes were timing fixes.

| Measure | PR #82 | High-shot correction |
| --- | ---: | ---: |
| Visible-start correct | 125/239 | 127/239 |
| Server side correct | 163/239 | 164/239 |
| Timing fixes | — | 2 |
| Timing damages | — | 0 |
| Changed server answers | — | 1 |

This is a small and concentrated development result.
It is not a broad opener-recovery method.

## 7. Other rejected rules

| Candidate | Triggers or changes | Timing fixes | Timing damages | Other result |
| --- | ---: | ---: | ---: | --- |
| Broad serve-setup wrist differential | 138 | 22 | 63 | 53 changed but stayed wrong |
| Continued same-player setup | 2 | 1 | 1 | No server change |
| Relaxed incoming at the original first contact | 9 | 4 | 2 | Server: 5 fixes, 4 damages |
| Later incoming anchor with no admitted predecessor | 6 | 4 | 1 | 1 stayed wrong |
| Ordinary measured predecessor, different players | 26 | 3 | 10 | 13 stayed wrong |
| Drop rank 1 using later evidence, alternation, and server agreement | 24 | 7 | 9 | 8 stayed wrong |

These tests support the original follow-up's narrow conclusion.
The available 2D distance, contact order, pose, and alternation signals did not reveal a broad high-precision false-first-contact state.

## 8. Preferred 170 server rule

The later reconstruction reused the relaxed outgoing-selected evidence for server side instead of replacing the opener.

```text
if selected contact is incoming before contact:
    choose the other side
elif selected contact is not incoming:
    choose the selected contact's side
else:
    keep the PR #82 server answer
```

The branch results are:

| Branch | Rallies | Correct server sides |
| --- | ---: | ---: |
| Selected incoming; choose other side | 68 | 45 |
| Selected not incoming; choose selected side | 23 | 15 |
| PR #82 fallback | 148 | 110 |
| **Total** | **239** | **170** |

Its other scores are:

| Measure | Result |
| --- | ---: |
| Correct server sides | 170/239 |
| Correct timing slots | 132/239 |
| Both correct | 117/239 |
| Correct visible-serve frame claims | 97 |
| Changes from PR #82 | 33 |
| Fixes from PR #82 | 20 |
| Damages from PR #82 | 13 |

The server rate rises from 68.20% to 71.13% on the development set.
The exact two-sided paired p-value is 0.296.

The rule is label-free at prediction time within the fixed 239-rally population.
The rule itself was selected after reading development-set results.

## 9. Rank-1 fallback sensitivity

A nearby sensitivity replaces the PR #82 fallback with a rank-1 rule.

```text
if the outgoing-selected contact is classifiable:
    use the same branch as the preferred rule
elif rank-1 pre-contact motion is incoming:
    choose the other side from rank 1
else:
    choose the rank-1 player's side
```

| Branch | Rallies | Correct server sides |
| --- | ---: | ---: |
| Selected incoming; other side | 68 | 45 |
| Selected not incoming; selected side | 23 | 15 |
| Rank-1 incoming; other side | 3 | 3 |
| Rank-1 default; rank-1 side | 145 | 108 |
| **Total** | **239** | **171** |

This version has 171 correct server sides.
Its timing score is 131/239.
Its joint score is 117/239.

It changes 34 PR #82 answers.
It fixes 21 and damages 13.

The preferred 170 rule gives up one server hit and keeps one extra timing hit.
It also uses the existing PR #82 fallback instead of introducing a second unvalidated fallback rule.

## 10. Nearby diagnostics

The historical 160 count was coverage, not correctness.

| Direct source | Rallies | Correct server sides |
| --- | ---: | ---: |
| Outgoing-selected inference | 91 | 60 |
| Promoted rank-1 rows with no usable pre-run | 69 | 60 |
| **Total** | **160** | **120** |

A minimum-three-sample path sensitivity scored 166/239 after PR #82 fallback.
It did not beat the preferred rule.

There are 90 selected rows whose pre-contact path state is `no_usable_run`.
Sixty-nine of those rows select accepted-contact rank 1.

## 11. Arc-aware proposal

The proposed one-way arc rescue keeps all existing incoming calls.
It only reconsiders an existing not-incoming call.

A rescue requires:

| Condition | Threshold |
| --- | --- |
| Samples | At least 6 |
| Quadratic RMSE improvement over a line | At least 30% |
| Quadratic vertex | Between 20% and 80% of the path |
| Samples on each side | At least 3 |
| Early robust slope | Positive; distance increases |
| Late robust slope | Negative; distance decreases |
| Fitted late closure | At least 0.05 body heights |

The supplied zip directly demonstrates two rescues among eight plotted classifier errors.
Those points were digitised from an image.
The demo explicitly says it is not a full rerun on the original path samples.

A later audit reports this exact-path result:

| Reported endpoint | Before | After | Fixes | Damages |
| --- | ---: | ---: | ---: | ---: |
| Timing on 19 labelled usable paths | 11/19 | 13/19 | 2 | 0 |
| PR #82 server side over 239 rallies | 163/239 | 159/239 | 0 | 4 |
| Preferred rule with fallback-only arc change | 170/239 | 167/239 | 0 | 3 |

The exact path CSVs and the audit helper used for that result are not in the supplied tar, slim zip, or added `recompute_metrics.py` module.
This bundle therefore records those figures as an audit claim, not as a reproduced result.

The safe conclusion is unchanged.
The arc idea is at most a separate timing experiment.
It should not be added to the current server rule.

## 12. Limits

The bundled tables are enough to reproduce the original follow-up counts and the 170/171 re-scores.

They do not rerun TrackNet, pose inference, contact generation, or scene segmentation from raw video.

The 239-rally score is not an end-to-end rate over all 292 ground-truth rallies.

Every rule discussed here was examined on the same development fixtures.
The next useful evidence must come from unseen rallies.
