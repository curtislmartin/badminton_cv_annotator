# What happened

## 1. PR #82 started with server identification

PR #82 asked whether shuttle motion before the earliest accepted contact could improve the guess about who served.

The released alternating fit got 124 of 239 server sides right.
Choosing the player at the earliest accepted contact got 152 right.

PR #82 then checked whether the shuttle moved towards that player before the contact.
Incoming motion made the contact look like a first return.
The rule then chose the other side as server.

That direct correction got 163 server sides right.
It only had usable pre-contact motion in 24 rallies.

PR #82 also exposed a timing problem.
At ±10, 97 earliest accepted contacts matched no annotated stroke.
A later accepted contact matched the serve or first return in 85 of those 97 cases.

This showed that exact rally-start timing and server side were different problems.

## 2. The original follow-up narrowed the question

The original follow-up asked whether a spurious early contact shifted the accepted sequence out of phase.

Its simple model was:

```text
accepted contact 1 is false
real first contact appears as accepted contact 2
later contacts are shifted by one place
```

The main endpoint was the visible opener.
Server attribution was secondary.

The follow-up was told not to build a learned model, a large scoring stack, or a threshold search.
It had to show whether a simple backwards reconstruction worked.

## 3. The strict outgoing search failed

The first search required credible outgoing motion after a contact.
It skipped contacts until one passed that test.
It then used pre-contact motion to call the selected contact serve-like or return-like.

The rule often selected a late contact.
Its median selected rank was 3.

At ±10 it fixed 16 timing labels and damaged 34.
It was not safe as an opener replacement.

## 4. The H3/R8 pass made evidence less brittle

The next pass allowed a larger step-ratio limit and a smaller excluded-frame halo.
It also added a measured high-shot bridge for long predecessor gaps.

The relaxed outgoing search classified 91 rallies directly.
It left 148 unresolved.

As a timing replacement, it fixed 26 and damaged 13.
Its final timing score was still only 43/239.

The evidence contained useful server information.
It did not solve exact opener selection.

## 5. The predecessor search found one narrow state

The second relaxed search started from an incoming contact.
It then inspected the immediately preceding accepted contact.

Ordinary predecessor timing was weak.
The broader rules damaged more starts than they fixed.

The measured high-shot bridge appeared five times.
Two cases changed the PR #82 frame.
Both changes fixed the timing label.

The final original-follow-up rule allowed only that state to intervene.
It raised visible-start correctness from 125 to 127.
It raised server correctness from 163 to 164.

All five high-shot states came from one set.
The result was useful but too small to generalise.

## 6. Pose and combined rules were rejected

A broad wrist-proximity rule fired 138 times.
It fixed 22 starts and damaged 63.

A same-player continuation rule fired twice.
It fixed one and damaged one.

Ordinary predecessor, later-anchor, alternation, and server-agreement combinations also caused too much damage.

The original follow-up's final conclusion was coherent:

> The tested signals did not identify a broad false-first-contact state safely.

## 7. The reconstruction returned to server side

The reconstruction noticed that 67 rallies had the wrong visible-start interpretation but the right server side.

It reused the 91 classifiable outgoing-selected contacts as server evidence.
It kept PR #82 on the other 148 rallies.

That rule scored 170/239 server sides.
It was a valid new re-score of frozen evidence.
It was not the original follow-up's primary timing result.

## 8. The 160 and 171 figures were nearby analyses

The 160 figure counted direct answers.
It did not mean 160 correct answers.
The direct answers were correct in 120 cases.

The 171 sensitivity replaced the PR #82 fallback with a rank-1 rule.
It gained one server hit and lost one timing hit.
Its joint score stayed at 117.

The reconstruction preferred 170 because the fallback was simpler and preserved one more timing answer.
That is a reasonable development-set choice.

## 9. The arc proposal remained separate

The zip added a curved-path rescue for some not-incoming paths.
Its supplied demo used points digitised from an eight-error figure.
It rescued two plotted missed returns.

The later audit says exact samples confirm those two timing fixes but show server damage.
The exact inputs for that audit are not in the supplied bundle here.

The arc proposal should therefore remain outside the server rule.
It can only be tested as a separately frozen timing hypothesis.

## 10. Current state

For exact visible-start recovery, no broad safe rule has been found.
The high-shot correction is a small timing candidate.
The arc rule is an unconfirmed timing candidate in this bundle.

For server identification, the preferred outgoing-selected rule plus PR #82 fallback is the main 170/239 development candidate.

The next step is an unseen evaluation.
It is not another rule search over the same 239 rallies.
