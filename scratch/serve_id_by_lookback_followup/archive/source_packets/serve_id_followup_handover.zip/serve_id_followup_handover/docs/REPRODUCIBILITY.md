# Sources and reproducibility

## 1. What this bundle uses

The bundle keeps eight frozen source files from the original follow-up tar.

| File | Role |
| --- | --- |
| `accepted_contact_trace_rows.csv.gz` | Strict outgoing-first per-rally results |
| `accepted_contact_trace_summary.json.gz` | Strict thresholds and counts |
| `h3_r8_contact_evidence.csv.gz` | Frozen per-contact motion evidence |
| `h3_r8_search_results.csv.gz` | Relaxed outgoing and predecessor search results |
| `h3_r8_summary.json.gz` | Relaxed thresholds and counts |
| `additive_correction_results.csv.gz` | PR #82 baseline and high-shot correction rows |
| `additive_correction_summary.json.gz` | High-shot and rejected-rule summaries |
| `serve_setup_continuation_summary.json.gz` | Pose-rule sensitivities |

`results/development_metrics.json` records the byte size and SHA-256 hash of each source file.

## 2. What was checked

The main frozen evidence files in the reconstruction zip are byte-for-byte copies of the original tar files.

The preferred 170 rule was recomputed from the relaxed search table and the PR #82 baseline table.

The 171 rank-1 sensitivity was recomputed from those tables plus the rank-1 contact rows.

The original strict, relaxed, high-shot, and pose counts were read from the frozen summaries and checked against their row tables where applicable.

The 292/249/239 population context and the 124/152/159 PR #82 comparison values come from the PR #82 report. The bundled recomputation does not rebuild those reference values from raw video.

The bundled tests check the headline values and compare fresh deterministic outputs with the committed result files.

## 3. How to rerun

From this directory:

```bash
python -m serve_id_followup.recompute
python -m serve_id_followup.recompute --check
python -m unittest discover -s tests -v
```

The recomputation uses only the Python standard library.
Gzip outputs use a fixed timestamp, so identical inputs produce identical bytes.

## 4. Ground-truth boundary

The 170 and 171 prediction branches use only frozen contact, player, and trajectory fields.
They choose a server before ground truth is read for scoring.

Two qualifications remain.

The 239-rally population comes from a ground-truth rally-to-span crosswalk.
The result is therefore label-free within that fixed population, not an end-to-end estimate over all rallies.

The rule composition was chosen after the same development labels were inspected.
It is model selection on labelled data even though runtime branches do not read labels.

## 5. Problems in the supplied reconstruction packet

The reconstruction zip greatly improved the prose and preserved the main evidence.
It still had packaging defects.

The added `recompute_metrics.py` was stored at the zip root.
Its data and companion scripts were under `serve_id_followup_packet_v3/supporting/`.
The script looks for all of them beside itself, so it cannot run in place.

After moving the script beside the supporting files, it reproduces the headline JSON.
It also reproduces the decompressed 170 and 171 CSV outputs.

It does not reproduce these four stored derived tables exactly:

- `current_server_reanalysis.csv.gz`;
- `minimum_path_3_sensitivity.csv.gz`;
- `no_usable_pre_run_cases.csv.gz`;
- `apparent_return_cases.csv.gz`.

Some differences are column names and null handling.
Some are semantic fields such as direct-correct flags and claimed labels.
The headline counts remain the same, but the packet contains mixed generations of derived data.

This bundle omits those redundant tables.
It builds the two decision tables and one metrics file from one code path.

The two supplied copies of `recompute_metrics.py` are byte-for-byte identical.

## 6. Arc result status

The zip contains a digitised eight-error arc demo.
It does not contain exact per-frame path samples for all 19 labelled usable paths.

The later audit documents an exact 19-path calculation and a harmful server effect.
That audit says it used a separate trajectory archive and a helper named `recompute_arc_exact.py`.
Neither the archive nor that helper was supplied with the current files.

The exact arc figures are retained in `docs/RESULTS.md` as an audit claim.
They are not included in `development_metrics.json` and are not described as reproduced here.

## 7. What was not rerun

This bundle does not rerun raw-video TrackNet extraction.
It does not rerun pose inference.
It does not rebuild accepted contacts or scene spans.

Those low-level stages require repository code and large inputs that are not present in the supplied archives.
The frozen tables remain the source record for this handover.

## 8. Why the original tar is not commit material

The original tar has 389 members, including 26 symlinks and many agent runtime files.
It contains logs, crash files, conversation databases, transcript files, and whole agent home directories.

It also contains files named `oauth_creds.json` and `google_accounts.json`.
Their contents were not opened during this reconstruction.
Treat the tar as sensitive.
Do not put it in Git or attach it to a public issue.

If that tar has already been shared outside a trusted boundary, review and revoke any credentials that may have been captured.

## 9. Source relationship

The clean provenance is:

1. PR #82 asked the broad server-identification question.
2. The original follow-up tar narrowed that into visible-opener reconstruction.
3. The reconstruction zip returned to server side and added the 170/171 re-scores.
4. The later audit corrected the scope account and challenged the arc recommendation.
5. This bundle keeps the supported results, removes runtime clutter, and marks unreproduced claims clearly.
