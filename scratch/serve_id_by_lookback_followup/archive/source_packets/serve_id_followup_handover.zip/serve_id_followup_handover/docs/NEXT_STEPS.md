# What to test next

## 1. Freeze the 170 server rule

Use this rule without changes:

```text
if relaxed outgoing-selected category is first_visible_post_serve_contact:
    choose the other side from the selected contact player
elif category is visible_serve:
    choose the selected contact player's side
else:
    keep the PR #82 server answer
```

Do not add the arc rescue.
Do not replace the fallback with the 171 sensitivity before the first unseen test.
Do not change path thresholds after reading unseen labels.

## 2. Report three outputs

For each rally, report:

| Output | Meaning |
| --- | --- |
| Server side | Predicted side equals the ground-truth server side |
| Timing slot | Serve claim matches contact 1, or return claim matches contact 2 |
| Joint | Both server side and timing slot are correct |

Also report the paired change from PR #82:

| Paired outcome | Meaning |
| --- | --- |
| Fix | New rule right, PR #82 wrong |
| Damage | New rule wrong, PR #82 right |
| Both correct | Neither gains nor loses |
| Both wrong | Neither gains nor loses |

The development reference is:

| Measure | PR #82 | Preferred rule |
| --- | ---: | ---: |
| Server side | 163/239 | 170/239 |
| Timing slot | 125/239 | 132/239 |
| Joint | 96/239 | 117/239 |
| Fixes | — | 20 |
| Damages | — | 13 |

## 3. Keep the population clear

When data allow, show both of these views:

1. The fixed one-to-one population used by this development analysis.
2. A broader end-to-end population that includes uncovered and merged rallies.

Always show the narrowing:

```text
all ground-truth rallies
    -> covered rallies
        -> one-to-one rallies
            -> classifiable outgoing evidence
```

A gain on the last group may not improve the full pipeline.

## 4. Test timing candidates separately

The high-shot predecessor rule should remain a separate frozen timing hypothesis.
All five development states came from one set.
Report how often the state appears before reporting its precision.

The arc rule should also remain separate.
Use the exact thresholds recorded in `docs/RESULTS.md`.
Apply the rule to every unseen usable path, not only known errors.

For each arc path, retain:

- sample count;
- line and quadratic errors;
- error improvement;
- vertex position;
- samples on each side;
- robust early and late slopes;
- fitted late closure;
- old and new timing calls;
- old and new server sides.

The primary arc question is whether timing improves without damaging previously correct timing calls.
The server effect must still be reported.

## 5. Stop adding thresholds to the same distance trace

The previous work already tested strict and relaxed outgoing motion, predecessor links, high-shot gaps, alternation, server agreement, wrist proximity, and a curved-path rescue.

The broad combinations caused too much damage.
A monocular 2D distance trace cannot reliably encode shuttle height, depth, and stroke ownership.

If exact opener timing still needs a large gain, add a new observation.
The most direct candidate is local RGB evidence of a physical stroke around the accepted frame.
That could use racket or hitting-arm motion.

Frame it as contact verification.
Do not frame it as another threshold layer over the same scalar distance path.
