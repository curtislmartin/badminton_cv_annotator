# What to commit

Commit this directory as one self-contained handover.

## Keep

```text
README.md
COMMIT_MANIFEST.md
serve_id_followup/
tests/
docs/
data/
results/
```

The `data/` files are small frozen evidence tables.
They are needed to reproduce the checked outputs.

The `results/` files are deterministic products of the bundled module.
They are useful for review without running code.

## Leave out

Do not commit:

```text
serve_id_by_lookback_followup*.tar
serve_id_followup_packet*.zip
recompute_metrics*.py
AUDIT.md
README(20260812-035356).md
01_NARRATIVE*.md
02_TECHNICAL_EVIDENCE.md
03_ARC_AWARE_RESULT.md
04_NEXT_STEPS*.md
05_TRACEABILITY.md
MANIFEST.md
agent home directories
logs
conversation databases
credential files
```

The useful content from those loose files has been folded into this handover.
The original archives can remain in private local storage for forensic provenance.
They should not be part of the normal repository history.

## Suggested commit message

```text
Document serve-lookback follow-up and freeze server-ID evaluation
```
