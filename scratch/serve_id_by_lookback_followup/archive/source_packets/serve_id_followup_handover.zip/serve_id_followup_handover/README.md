# Serve lookback follow-up

## Summary

This folder turns the follow-up to [PR #82](https://github.com/ahalp90/badminton_cv_annotator/pull/82) into one readable handover.

The work contains two related questions.

1. **Where does the visible rally start?**
2. **Which side served?**

A start-frame answer can be wrong while the server-side answer is right.
The two results must therefore be reported separately.

The original follow-up mainly studied the first question.
It did not find a broad, safe way to recover the exact visible opener.
Its one positive rule was very narrow.
That high-shot predecessor rule changed two starts and fixed both on the same development data.

The later reconstruction returned to server identification.
It found a coherent candidate that uses the relaxed outgoing-contact inference when that inference is available.
It keeps the PR #82 answer otherwise.

| Result | Server side | Timing slot | Joint | Status |
| --- | ---: | ---: | ---: | --- |
| PR #82 reference | 163/239 | 125/239 | 96/239 | Existing development result |
| Narrow high-shot correction | 164/239 | 127/239 | Not used as a combined rule | Two changes from one set |
| Preferred outgoing-selected rule | **170/239** | **132/239** | **117/239** | Main candidate for an unseen test |
| Rank-1 fallback sensitivity | 171/239 | 131/239 | 117/239 | Nearby sensitivity, not the preferred rule |

The preferred rule changes 33 PR #82 answers.
It fixes 20 and damages 13.
The exact paired two-sided p-value is 0.296.
That is an exploratory result, not proof of a general improvement.

## Evaluation of the earlier work

The original follow-up reached a sound conclusion for the timing question it was asked.
It also kept useful frozen evidence.

The reconstruction zip was a large improvement in readability.
Its 170/239 server re-score is valid and reproducible from the saved tables.
Its prediction branches do not read ground truth before choosing a side.

The reconstruction still had three important problems.

First, it described server identification as though it were the original follow-up's main endpoint.
The original follow-up made visible-start recovery primary and server attribution secondary.

Second, it treated the arc idea too confidently.
The supplied zip directly supports only a digitised demonstration on eight plotted errors.
A later audit reports an exact 19-path timing gain and harmful server changes.
The exact path samples and audit helper used for that claim are not in the supplied archives here.
This handover keeps the claim, but does not mark it as reproduced.

Third, the packet was not internally clean.
The supplied `recompute_metrics.py` sits outside the directory that contains its inputs and companion scripts.
After moving it so it can run, it reproduces the headline JSON and the 170/171 outputs.
It does not reproduce four other stored derived tables exactly.
This handover replaces that split state with one deterministic recomputation module and tests.

## Current decision

Freeze the preferred 170 rule and test it on unseen rallies.
Do not tune it again on these 239 rallies.

Keep timing and server side as separate outputs.
Also report the joint result.

Do not add the arc rescue to the server rule.
The directly supplied material does not establish a safe server-side use.

Do not commit the original tarball.
It contains agent runtime directories, logs, conversation databases, symlinks, and files with credential-like names.
This handover does not copy any of them.

## Read order

1. `README.md` gives the decision and the important numbers.
2. `docs/RESULTS.md` records the methods, thresholds, counts, and limits.
3. `docs/EXPERIMENT_HISTORY.md` explains what was tried and why the question changed.
4. `docs/NEXT_STEPS.md` states the smallest useful next tests.
5. `docs/REPRODUCIBILITY.md` maps the sources and explains what can be rerun.
6. `COMMIT_MANIFEST.md` says what belongs in Git and what does not.

## Recompute the results

This bundle uses only the Python standard library.

```bash
python -m serve_id_followup.recompute
python -m serve_id_followup.recompute --check
python -m unittest discover -s tests -v
```

The checked outputs are in `results/`.
The frozen inputs are in `data/`.
