# Primary review
Gemini 3.8 Flash high returned concrete leads. Launcher exit4 was a staging false alarm: the input directory was not its own git tree, so launcher observed concurrent authorised parent/worker edits in the enclosing repository. git -C input rev-parse confirmed enclosing root; cmp of both reviewed new modules passed. Reviewer used file reads only. Next review stage will be outside any git tree to avoid this issue.

1. Excluding misses from side-among-matched counts is intentional; all GT denominator remains known_side_firsts for joint measure. Reject recommendation to mix missed timing with missing SIDE.
2. Wrong-time starts are joint-incorrect without a known side label. Keep joint denominator, make row judgeable_side consistent with joint counting. No need to change result definition.
3. Retain raw/final guesses on unmatched start rows: fixed. Their missing_label status means no matching target, not an annotator omission; table counts sides only among matched serves.
4. Accepted and all start statuses need separate names: added accepted_* counters; retained all statuses and all rows. accepted_serves projects saved matches into accepted membership and avoids repeated matching.
5. Duplicate opportunity note is valid terminology limit: nearby duplicate flag overlaps interior/start roles; actual useful target still re-matches and preserves GT indices. No target bug.
No new tests beyond relevant counters and existing requested boundary fixtures.
