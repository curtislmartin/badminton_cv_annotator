### Audit Findings

#### 1. Demonstrated Defect: Variant Key Mismatch Between Fitted Models and Policy/Curve Records
* **File & Lines**: [`scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py:92-105, 109-111`](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py#L92-L105)
* **Evidence**:
  * Lines 92–93 fit nested models keyed as `{"control": ..., "gaps": ...}` and line 97 accesses `models["gaps"]`.
  * Lines 100–101 store `"control_score"` and `"gap_score"`.
  * Lines 104–105 compute curves and policies using singular keys:
    `curves = {key: _tail_curve(output_rows, f"{key}_score") for key in ("control", "gap")}`
    `policies = {key: next(...) for key, curve in curves.items()}`
  * Line 109 fits final models using plural `"gaps"`:
    `final = {"control": fit_acceptor(matrix[:, :width], answers), "gaps": fit_acceptor(matrix, answers)}`
  * Line 110–111 dumps `final` and `policies` together into `gap_acceptance_models.joblib`.
* **Impact**: In the dumped checkpoint and nested training dict, the model mapping uses `"gaps"` while policies, curves, and row score keys use `"gap"`. Any downstream consumer looking up `payload["models"][variant]` with `variant` from `policies` or `curves` fails with `KeyError: 'gap'`.
* **Smallest Fix**: Standardize on `"gap"` in [run_gap_acceptance.py](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py):
  * Line 93: `"gap": fit_acceptor(np.vstack(train_gap), answers)`
  * Line 97: `gap_scores = _positive_scores(models["gap"], gap)`
  * Line 109: `final = {"control": fit_acceptor(matrix[:, :width], answers), "gap": fit_acceptor(matrix, answers)}`

---

#### 2. Unresolved Assumption / Defect: Pair Cache Lookup Assumes Lexicographically Sorted `GROUPS`
* **File & Lines**: [`scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py:59-62`](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py#L59-L62)
* **Evidence**:
  * Line 60 constructs the nested pair cache key via:
    `key = "".join(sorted(allowed))`
  * In [run_later_acceptance.py:185, 207](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_later_acceptance.py#L185), cache keys in `nested_pair_fits.joblib` were saved using `itertools.combinations(GROUPS, 2)`:
    `key = "".join(pair_tuple)`
  * In [run_later_acceptance.py:392](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_later_acceptance.py#L392), lookup matches canonical definition order:
    `pair = "".join(group for group in GROUPS if group not in {held_group, training_group})`
* **Impact**: If `GROUPS` in `whole_rally_learning` is not defined in strictly alphabetical order, `"".join(sorted(allowed))` generates permuted keys that miss `pairs["pair_scores"]` and `pairs["pair_references"]`, raising an immediate `KeyError`.
* **Smallest Fix**: In [run_gap_acceptance.py:60](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py#L60), preserve `GROUPS` canonical order:
  ```python
  key = "".join(group for group in GROUPS if group in allowed)
  ```

---

### Audit Verification of Stated Invariants

1. **Identical Current Detector Outputs**: Verified. [run_gap_acceptance.py:63-68](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/run_gap_acceptance.py#L63-L68) extracts both control (`features`) and gap features (`ordered_gap`) from the same `selected` choices. For outer folds, line 67 asserts `option.span == current_selection[identity].span` against `later_margin_predictions.json.gz`.
2. **Exclusion of Outer and Row Groups**: Verified. Training folds pass `allowed - {group}` to `pairs` scores/references and `local["models"]`, excluding both outer and row groups. Outer evaluation uses `local["models"][allowed]`, excluding the outer group. Upstream detector cross-group dependence is disclosed (line 116).
3. **Candidate Context**: Verified. [gap_evidence.py:64-76](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/gap_evidence.py#L64-L76) builds context from `selected.span`, correctly conditioning candidate local features on the selected edited contacts.
4. **Missing Proposal Handling**: Verified. [gap_evidence.py:50-61](file:///home/ariel/Documents/COSC594/badminton_cv_annotator/scratch/contact_det_closing_pass/scripts/gap_evidence.py#L50-L61) returns `np.nan` for sections lacking candidates; no pseudo-evidence of completeness is injected.
5. **Session-Start Detector Target & Policy**: Verified. Lines 111 and 114 label `"detector": "session_start"`. Line 105 isolates `top20pct` while line 104 preserves the full descriptive curve. No automatic trust claims are made.
