# Primary review

Opus4.6 thinking read-only, model-defined effort; isolated 10-source bundle; no writes. Launcher exit0, unchanged input tree.

Verified nested cache exclusions, keep-positive targets, fixed-side section scoring and label-free options directly before launch. Opus agrees; this is supporting review rather than proof.
Cumulative variant limitation accepted: opening scores and raw-side features enter together. This tests their combined impact; no attribution to either alone. Full variant then isolates added direct physical inputs conditional on both. Note opening scores already contain physical evidence.
Legacy flattened source names in the audit bundle refer to the actual imported files; the report's comment that renamed copies are not imports is a packaging observation, not an independent implementation distinction.
The duplicate-removal metric already has a focused case where a deleted matched prediction is replaced by a surviving duplicate. It counts preserved GT coverage and reduced unmatched predictions, not prediction-identity preservation. No additional speculative fuzzing needed.
NaN physical feature values are inputs only, not serialised matrices. HGB predictions are finite on these inputs; a JSON serialisation error would fail loudly. No silent-error claim or defensive sweep needed.
No material blocker or required code change from this audit.
