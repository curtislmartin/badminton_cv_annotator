Gemini3.8Flashhigh completed source review. Launcher exit4 tripwire is confounded by concurrent primary commit66240e5: git -C isolated/input resolves to the parent experiment repository, whose status changed when primary committed. No reviewer edits applied. Review report says no edits; input bundle remains the supplied nine source files. Do not treat launcher tripwire as a passing independent integrity certificate.

Material review: nested downstream group exclusions and save-before47labels confirmed. Six proposed leads checked:
1. Nonempty fallback requires32judged by declared design. FixedD has ample judged rows; report all five nonempty curve points even if no supported rule. No need fallback below evidence minimum. Removed harmless `precision or -1` because fallback candidates already have>=32judged, hence precision alwaysdefined.
2. All fixedD/47 videos have generatedsections; empty sections are kept as keepoptions. Zero-section fixture hypothetical is outside this run, and reshaping alone would stillleaveHGBunabletopredictzero. No new fallback.
3. section_views alwayssupplies group in both callers; missinggroup scenarioexcluded.
4. Rejectedcorrectcounts plusacceptedcorrectcounts alreadygive requestedaccounting; recallratio canbederived inreport. No missingdenominator.
5. If originalvoteagreement isNaN, allcandidate improvements subtractthatNaN andremainunknown; iforiginalfinite, addinga contactpreservesatleastoneknownside soallimprovementsfinite. No mixedfinite/NaNordering bug.
6. _expanded_matrix argumentnames explicitlybindcorrectarrays; stackingorderneednotmatchsignatureorder and keywordcalls do notswapthem. No bug.

No experiment settings or candidate rules changed following audit.
