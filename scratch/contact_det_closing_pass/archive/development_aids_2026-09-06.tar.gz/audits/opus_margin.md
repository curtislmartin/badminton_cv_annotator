# Primary review

Opus4.6 Thinking completed its isolated read-only consultation (launcher0). No material code defect was established.

1. The development comparison intentionally preserves the ungated chooser. The new `run_later_margin.py`, outside this narrow source bundle, produces `later_margin_result.json.gz` and `later_margin_predictions.json.gz`. The completed replay has1,095 correct/112 repairs/8 losses at10, using the same helper as nested acceptance and broader inference. The reviewer attributed this headline to the wrong artefact. Keep both outputs separately named in the report; no code change needed.
2. The reviewer confirms pair-specific references stay inside the outer acceptance exclusions and global reference choices supply only the actual held-group features.
3. Pair fits have fewer training groups than final/global fits. This is the expected nested-validation distribution difference, not evidence of a defect or reason for another run.

Initial launcher attempts failed before a model ran because required metadata and the timeout unit were omitted; the completed retry used10m. This was CLI invocation correction, not an automatic approval rejection. Source bundle was under/tmp to avoid a parent-repository status change confounding a read-only tripwire. No reviewer edits were applied.
