import gzip
import json
from collections import Counter
from pathlib import Path
from statistics import mean, median

ROOT = Path('scratch/contact_det_closing_pass')

def read(name):
    with gzip.open(ROOT / name, 'rt') as source:
        return json.load(source)

def paired(before, after):
    old = {(row['fixture'], row['rally_id']) for row in before if row['fully_correct']}
    new = {(row['fixture'], row['rally_id']) for row in after if row['fully_correct']}
    return {'correct': len(new), 'repairs': len(new-old), 'losses': len(old-new), 'net': len(new)-len(old)}

result = read('results/broader_result.json.gz')
predictions = read('results/broader_predictions.json.gz')
inputs = read('raw/broader_inputs/chooser_inputs.json.gz')
systems = result['systems']
facts = {'population': {'videos': result['video_count'], 'sections': result['sections']},
         'systems': {}, 'action_counts': result['action_counts'],
         'combined_versus_opening': {}, 'by_video': []}
for name, system in systems.items():
    facts['systems'][name] = {}
    for tolerance in ('10', '5'):
        comparison = system['evaluation'][tolerance]['paired_fixed_side']
        facts['systems'][name][tolerance] = {
            'correct': comparison['correct_after'],
            'repairs': len(comparison['repaired']), 'losses': len(comparison['lost']),
            'contacts': system['contacts'][tolerance]['fixed_side']['total'],
        }
        if name == 'combined':
            facts['systems'][name][tolerance]['harm'] = system['harm'][tolerance]['counts']
for tolerance, comparison in result['combined_versus_opening'].items():
    facts['combined_versus_opening'][tolerance] = {
        'repairs': len(comparison['repaired']), 'losses': len(comparison['lost'])}
acceptance = systems['combined']['acceptance']
fallback_threshold = acceptance['frozen_rules']['fallback_rule']['threshold']
fallback = next(row for row in acceptance['curve'] if row['threshold'] == fallback_threshold)
facts['acceptance'] = {key: value for key, value in fallback.items() if key not in ('by_video', 'by_group')}
facts['acceptance_curve'] = []
for row in acceptance['curve']:
    facts['acceptance_curve'].append({key: row[key] for key in ('threshold','accepted_count','coverage','by_tolerance')})
reasons = {}
for tolerance in ('10', '5'):
    reasons[tolerance] = dict(Counter(row['judgements'][tolerance]['reason']
        for row in acceptance['rows'] if row['score'] >= fallback_threshold))
facts['accepted_reasons'] = reasons
input_by_video = {row['fixture']: row for row in inputs['videos']}
prediction_by_video = {row['fixture']: row for row in predictions['videos']}
for fixture in sorted(prediction_by_video, key=int):
    row = {'fixture': fixture, 'systems': {}}
    for tolerance in ('10', '5'):
        base = systems['baseline']['evaluation'][tolerance]['edited_fixed_side']['sections']
        base = [section for section in base if section['fixture'] == fixture]
        row['sections'] = len(base)
        for name, system in systems.items():
            sections = system['evaluation'][tolerance]['edited_fixed_side']['sections']
            sections = [section for section in sections if section['fixture'] == fixture]
            row['systems'].setdefault(name,{})[tolerance] = paired(base, sections)
    row['acceptance'] = fallback['by_video'][fixture]
    timings = prediction_by_video[fixture]['timings']
    row['input_seconds'] = input_by_video[fixture]['generation_seconds']
    row['chooser_seconds'] = sum(value for key,value in timings.items() if key != 'opening_only_select_apply_seconds')
    row['extra_seconds'] = row['input_seconds'] + row['chooser_seconds']
    facts['by_video'].append(row)
for tolerance in ('10', '5'):
    nets = [row['systems']['combined'][tolerance]['net'] for row in facts['by_video']]
    facts.setdefault('video_net_counts',{})[tolerance] = {
        'positive': sum(value>0 for value in nets), 'zero': sum(value==0 for value in nets),
        'negative': sum(value<0 for value in nets)}
timings = {'prediction_runner_seconds': result['timings']['prediction_seconds'],
           'prediction_and_evaluation_seconds': result['timings']['total_seconds'],
           'side_vote_seconds': result['side_vote_seconds']}
for field in ('input_seconds','chooser_seconds','extra_seconds'):
    values = [row[field] for row in facts['by_video']]
    timings[field] = {'total':sum(values),'mean':mean(values),'median':median(values),'min':min(values),'max':max(values)}
facts['timings'] = timings
facts['physical_join'] = {
    'requested': sum(row['feature_join_audit']['requested_identity_count'] for row in predictions['videos']),
    'missing': sum(row['feature_join_audit']['missing_identity_count'] for row in predictions['videos']),
}
facts['opening_edits'] = sum(len(row['selected_opening']) for row in predictions['videos'])
(ROOT/'worklog/broader_facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps({key:value for key,value in facts.items() if key!='by_video'},indent=2))
