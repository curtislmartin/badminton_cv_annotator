#!/usr/bin/env bash
set -uo pipefail
cd /scratch/ahalperi/contact_det_closing_pass/repo-followups
export PYTHONPATH="$PWD/src:$PWD"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
export VLM_WORK_ROOT=/scratch/ahalperi/vlm-multiscale-cleanup
export VLM_SOURCE_ROOT="$PWD/src"
export VLM_HF_CACHE=/scratch/ahalperi/vlm-multiscale-cleanup/cache/huggingface
export VLM_QWEN38_IMAGE=/scratch/ahalperi/vlm-multiscale-cleanup/images/qwen3.8-vllm-v0.17.0.sif
export VLM_QWEN38_PYTHON=/scratch/ahalperi/vlm-multiscale-cleanup/envs/qwen3.8-v0.17.0-72afb9dc802c-7e9df187a7df/bin/python
export APPTAINERENV_HF_HUB_OFFLINE=1
vlm_input=/scratch/ahalperi/vlm-multiscale-cleanup/runs/contact-det-gap-acceptance-input-v1
vlm_output=/scratch/ahalperi/vlm-multiscale-cleanup/runs/contact-det-gap-acceptance-qwen-v1
/home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.prepare_vlm_acceptance \
  --artifacts-root /scratch/cmarti/issue103_ad8da4f/artifacts --output "$vlm_input"
build_exit=$?
if [ "$build_exit" -eq 0 ]; then
    bash scratch/vlm_pr80_eval/experiments/rally_start_remote.sh qwen3-8 "$vlm_input/manifest.json" "$vlm_output"
    model_exit=$?
    /home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.score_vlm_acceptance \
      --routing "$vlm_input/routing.json" --attempts-root "$vlm_output"
    score_exit=$?
    run_exit=$model_exit
    if [ "$score_exit" -ne 0 ]; then run_exit=$score_exit; fi
else
    run_exit=$build_exit
fi
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/followup_vlm.exit
tmux wait-for -S contact-followup-vlm-done
exit "$run_exit"
