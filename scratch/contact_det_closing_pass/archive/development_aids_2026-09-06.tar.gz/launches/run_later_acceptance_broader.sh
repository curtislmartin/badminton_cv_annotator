#!/usr/bin/env bash
cd /scratch/ahalperi/contact_det_closing_pass/repo || exit 1
export PYTHONPATH="$PWD/src:$PWD"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
"$HOME/.venvs/venv-bst-x/bin/python" -m scratch.contact_det_closing_pass.scripts.run_later_acceptance \
  > scratch/contact_det_closing_pass/worklog/later_acceptance.log 2>&1
run_exit=$?
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/later_acceptance.exit
if [ "$run_exit" -eq 0 ]; then
  if [ ! -f scratch/contact_det_closing_pass/worklog/later_broader_inputs.exit ]; then
    tmux wait-for contact-later-broader-inputs-done
  fi
  read -r input_exit < scratch/contact_det_closing_pass/worklog/later_broader_inputs.exit
  if [ "$input_exit" -eq 0 ]; then
    "$HOME/.venvs/venv-bst-x/bin/python" -m scratch.contact_det_closing_pass.scripts.run_later_broader \
      > scratch/contact_det_closing_pass/worklog/later_broader.log 2>&1
    run_exit=$?
  else
    run_exit=$input_exit
  fi
fi
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/later_acceptance_broader.exit
tmux wait-for -S contact-later-acceptance-broader-done
exit "$run_exit"
