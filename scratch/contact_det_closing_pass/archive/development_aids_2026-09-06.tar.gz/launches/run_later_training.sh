#!/usr/bin/env bash
set -uo pipefail
cd /scratch/ahalperi/contact_det_closing_pass/repo
export PYTHONPATH="$PWD/src:$PWD"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
"$HOME/.venvs/venv-bst-x/bin/python" -m scratch.contact_det_closing_pass.scripts.run_later_comparison
run_exit=$?
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/later_training.exit
tmux wait-for -S contact-later-training-done
exit "$run_exit"
