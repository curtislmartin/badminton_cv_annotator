#!/usr/bin/env bash
set -uo pipefail
cd /scratch/ahalperi/contact_det_closing_pass/repo-followups
export PYTHONPATH="$PWD/src:$PWD"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
/home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.prepare_early_broader_inputs \
  --saved-root scratch/contact_det_full_ds_fit/raw/shuttleset22-test-predictions \
  --prepared-root /scratch/cmarti56/issue106-shuttleset22-data/extracted-simple \
  --inpaint-root /scratch/ahalperi/contact_det_full_ds_fit/shuttleset22-inpainted-extract --jobs 4 &&
/home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.run_insertion_broader \
  --variant early --jobs 4 &&
/home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.run_boundary_broader \
  --variant early --boundary-mode fixed_membership
run_exit=$?
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/followup_early_broader.exit
tmux wait-for -S contact-followup-early-broader-done
exit "$run_exit"
