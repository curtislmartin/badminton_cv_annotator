#!/usr/bin/env bash
set -uo pipefail
cd /scratch/ahalperi/contact_det_closing_pass/repo-followups
export PYTHONPATH="$PWD/src:$PWD"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1
/home/ahalperi/.venvs/venv-bst-x/bin/python -m scratch.contact_det_closing_pass.scripts.run_insertion_broader --variant local --jobs 4
run_exit=$?
printf '%s\n' "$run_exit" > scratch/contact_det_closing_pass/worklog/followup_local_broader.exit
tmux wait-for -S contact-followup-local-broader-done
exit "$run_exit"
